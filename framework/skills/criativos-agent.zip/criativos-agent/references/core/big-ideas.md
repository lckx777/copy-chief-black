# Big Ideas para Direct Response

> **Frameworks e técnicas para criar conceitos únicos que diferenciam criativos e escalam sem concorrência.**

## Sumário
1. [O que são Big Ideas](#o-que-são-big-ideas)
2. [Big Idea vs Estrutura vs Ângulo](#big-idea-vs-estrutura-vs-ângulo)
3. [Por Que Big Ideas Escalam](#por-que-big-ideas-escalam)
4. [Ciclo de Vida da Big Idea](#ciclo-de-vida-da-big-idea)
5. [4 Pilares para Criar Big Ideas](#4-pilares-para-criar-big-ideas)
6. [Fontes de Big Ideas](#fontes-de-big-ideas)
7. [Big Idea vs Modelagem](#big-idea-vs-modelagem)
8. [Framework de Criação](#framework-de-criação)
9. [Big Ideas por Nicho](#big-ideas-por-nicho)
10. [Anti-Patterns](#anti-patterns)
11. [Case: Conteúdo Orgânico](#case-conteúdo-orgânico)

---

## O que são Big Ideas

**NÃO é:**
- Estrutura técnica do body
- Gimmick name vazio
- Clickbait sem substância

**É:**
- A **TESE CRIATIVA** que chama atenção
- Conceitos poderosos que geram curiosidade irresistível
- Ângulos que fazem a lead PARAR e querer saber mais
- O "gancho conceitual" que diferencia seu criativo

---

## Big Idea vs Estrutura vs Ângulo

**Diferença crítica:**

| Conceito | Definição | Exemplo |
|----------|-----------|---------|
| **Estrutura** | Como o anúncio é organizado | hook → história → mecanismo → CTA |
| **Ângulo** | A abordagem/perspectiva | mãe ocupada, homem cético, etc. |
| **Big Idea** | O conceito único que ninguém mais está usando | "Quase fui preso por usar IA" |

**Big Idea ≠ Hook**
- Hook é a primeira frase
- Big Idea é o CONCEITO por trás de todo o criativo

---

## Por Que Big Ideas Escalam

No mercado atual (2026):
- Leads com dopamina baixa
- Scroll infinito = atenção de segundos
- Copys genéricas são ignoradas
- Só o DIFERENTE para e prende

Quando todo mundo está modelando os mesmos anúncios da biblioteca, fazendo as mesmas estruturas, usando os mesmos ângulos, uma Big Idea nova **não tem concorrência**.

Você escala sozinho até o mercado começar a copiar. Isso pode levar semanas ou meses.

---

## 🚨 Framework Khayat: 3 Elementos Obrigatórios

> **REGRA:** Se a pessoa NÃO consegue contar pra alguém, NÃO é Big Idea.
> Big Idea genérica = criativo genérico = falhou.

### Definição Operacional

**Big Idea é a resposta para:** "O que torna esse anúncio CONTÁVEL para outra pessoa?"

Se a pessoa consegue sair e falar: "Nossa, vi um anúncio hoje que [___]" → isso é Big Idea.

Se o anúncio é só: "Perca X quilos em Y dias com esse método" → **NÃO** tem Big Idea, é só promessa crua.

### Os 3 Elementos (TODOS obrigatórios)

| Elemento | Pergunta | Exemplo Ruim | Exemplo Bom |
|----------|----------|--------------|-------------|
| **1. PERSONAGEM** | Quem está contando? Qual POV diferente? | "Especialistas dizem" | "Programador de cursinho que vazou os comandos" |
| **2. CENA** | Qual situação específica (como filme)? | "Recentemente descobri" | "Recebeu print no WhatsApp às 23h de um amigo" |
| **3. TENSÃO** | O que é estranho/proibido/urgente/curioso? | "Método eficaz" | "Pode ser processado por revelar" |

### Contability Test (BLOQUEANTE)

```
ANTES de escrever qualquer hook, complete esta frase:

"Nossa, vi um anúncio hoje que ________________________________"

✅ VÁLIDO: "...um cara que trabalha em cursinho mostrou que eles
            usam ChatGPT pra criar 90% do conteúdo"

❌ INVÁLIDO: "...ensina a emagrecer" (promessa crua)
❌ INVÁLIDO: "...tem um método bom" (genérico)
❌ INVÁLIDO: "...fala sobre concursos" (vago)
```

**SE não conseguir completar a frase de forma interessante → Big Idea ainda não existe → PARAR e ideiar.**

### Checklist de Big Idea (Antes de Produzir)

```
□ PERSONAGEM definido? (não é "expert" genérico)
□ CENA específica? (quando, onde, como aconteceu)
□ TENSÃO presente? (por que alguém pararia pra ouvir?)
□ Contability Test passou? (consigo contar pra alguém?)
□ É diferente dos outros 20 anúncios do feed?
```

---

## Ciclo de Vida da Big Idea

1. **Descoberta/Criação**
   - Você identifica ou cria uma Big Idea nova
   - Ninguém mais está usando

2. **Escala Inicial**
   - Pouca concorrência, CPAs baixos
   - Escala agressiva possível

3. **Imitação**
   - Mercado começa a perceber e copiar
   - Variações aparecem

4. **Saturação**
   - Big Idea entra na biblioteca
   - Todo mundo usa

5. **Declínio**
   - Performance cai, CPAs sobem
   - Público cansou

6. **Necessidade de Nova Big Idea**
   - Ciclo recomeça

---

## 4 Pilares para Criar Big Ideas

### 1. ELEMENTO DE PERIGO/RISCO

O cérebro é programado para prestar atenção em perigo.

**Fórmulas:**
```
"Eu quase [consequência grave] por [ação inesperada]"
"Fui [punido/processado/demitido] por [fazer X]"
"Quase perdi [algo valioso] quando [descobri Y]"
```

**Exemplos por nicho:**

| Nicho | Big Idea com Perigo |
|-------|---------------------|
| Concursos | "Quase fui preso por usar IA" |
| Saúde | "Quase morri por seguir conselho de médico" |
| Riqueza | "Quase fui preso por sonegar sem saber" |
| Relacionamento | "Quase perdi meu casamento por um conselho de coach" |

### 2. DESCOBERTA UNDERGROUND

Humanos amam segredos. Sensação de exclusividade.

**Fórmulas:**
```
"Uma comunidade secreta de [grupo] descobriu..."
"Existe um [método/grupo] que [autoridade] não quer que você saiba"
"Encontrei um [recurso] escondido que [resultado]"
```

**Exemplos:**
- "Turma do Fundão" - comunidade underground de aprovados
- "Receita proibida" - método que médicos não ensinam
- "Clube dos 1%" - estratégia de ricos que não divulgam

### 3. CONFLITO COM SISTEMA/AUTORIDADE

Cria polarização "nós vs eles". Gera identificação.

**Estrutura:**
```
[VOCÊ] vs [SISTEMA/AUTORIDADE]
    ↓
Descobriu verdade que eles escondem
    ↓
Resultado apesar da oposição
```

**Conflitos por nicho:**

| Nicho | Nós | Eles |
|-------|-----|------|
| Concursos | Concurseiros | Cursinhos caros |
| Saúde | Pacientes | Indústria farmacêutica |
| Riqueza | Povo | Bancos/Governo |
| Relacionamento | Homens/Mulheres | Coaches de relacionamento |

### 4. RESULTADO INESPERADO

Quebra de expectativa. Desafia lógica comum.

**Fórmulas:**
```
"Consegui [X] fazendo o CONTRÁRIO do que [autoridade] ensina"
"Descobri que [crença comum] é a maior mentira"
"Provei que [autoridade] estava completamente errada"
```

**Exemplos:**
- "Passei estudando 2h/dia enquanto quem estudava 10h reprovou"
- "Emagreci comendo mais do que antes"
- "Fiquei rico investindo no que o banco disse pra não investir"

---

## Fontes de Big Ideas

### 1. Outros Formatos de Mídia
- Conteúdo orgânico viral (Instagram, TikTok, YouTube)
- Podcasts
- Notícias/jornalismo
- Documentários

### 2. Outros Mercados
- O que está funcionando em outros países
- O que está funcionando em outros nichos
- Adaptar de B2B para B2C ou vice-versa

### 3. Mudanças Culturais
- Novos comportamentos do consumidor
- Novas tecnologias
- Novos medos/desejos coletivos
- Eventos atuais relevantes

### 4. Combinação de Elementos
- Juntar duas coisas que nunca foram juntadas
- Formato A + Comunicação B
- Ângulo de nicho X aplicado no nicho Y

---

## Big Idea vs Modelagem

| Modelagem | Big Idea |
|-----------|----------|
| Copia o que está funcionando | Cria algo que não existe |
| Compete com todo mundo | Compete sozinho (inicialmente) |
| Margens menores, escala limitada | Margens maiores, escala agressiva |
| Dependente da biblioteca | Independente da biblioteca |
| Reativa | Proativa |

**Nota importante:** Modelagem não é errada. É necessária para volume e consistência. Mas copywriters de elite **TAMBÉM** buscam Big Ideas constantemente. É o que gera os resultados extraordinários.

---

## Framework de Criação

### Passo 1: Identificar o Desejo do Avatar
```
O que ele REALMENTE quer?
- Concurseiro: Aprovação, estabilidade, reconhecimento
- Emagrecimento: Corpo bonito, autoestima, saúde
- Riqueza: Liberdade financeira, status, segurança
```

### Passo 2: Escolher 1-2 Pilares
```
PERIGO + UNDERGROUND = "Quase fui preso por descobrir uma comunidade secreta"
CONFLITO + RESULTADO = "Provei que o cursinho estava errado"
UNDERGROUND + RESULTADO = "Método secreto me deu o resultado que ninguém conseguia"
```

### Passo 3: Formular a Tese
```
[ELEMENTO IMPACTANTE] + [RESULTADO DESEJADO] + [COMO INESPERADO]

"Eu quase fui preso [PERIGO] por usar IA para ser aprovado [RESULTADO]
em um concurso que eu tinha reprovado 6 vezes [CONTEXTO]"
```

### Passo 4: Validar com Checklist
```
□ Gera CURIOSIDADE imediata?
□ Tem CONFLITO (nós vs eles)?
□ Carrega EMOÇÃO forte?
□ É ESPECÍFICA (não genérica)?
□ Conecta com DESEJO do avatar?
□ Parece VERDADEIRA (não clickbait)?
```

---

## Big Ideas por Nicho

### Concursos
```
"Quase fui preso por usar IA pra passar"
"O cursinho me processou por revelar o segredo"
"Reprovei 6x até descobrir o que os aprovados faziam escondido"
"O edital tem uma brecha que ninguém fala"
```

### Saúde/Emagrecimento
```
"Meu médico me proibiu de tomar isso. Funcionou."
"A indústria esconde esse ingrediente porque é barato demais"
"Emagreci 15kg comendo o que nutricionista proibiu"
"Quase morri seguindo dieta de influencer"
```

### Riqueza/Finanças
```
"Os bancos não querem que você saiba disso"
"Fui processado por ensinar isso de graça"
"O governo esconde essa brecha fiscal"
"Fiquei rico fazendo o oposto do que Primo Rico ensina"
```

### Relacionamento
```
"A mentira que contaram sobre o que homens querem"
"Quase perdi meu casamento por conselho de coach"
"O segredo que mulheres de relacionamentos longos não contam"
"Por que fazer tudo certo te deixa mais longe do amor"
```

---

## Anti-Patterns

### Gimmick Name Vazio
```
"Método X" - não tem conceito
"Sistema Revolucionário" - genérico
"Técnica Secreta" - não gera curiosidade real
```

### Clickbait Sem Substância
```
"Você não vai acreditar no que aconteceu" - sem promessa específica
"Isso vai te chocar" - sem direção
"A verdade sobre X" - vago demais
```

### Big Idea Sem Resultado
```
"Descobri algo incrível" - e daí?
"Ninguém sabe disso" - mas resolve o quê?
"É controverso" - mas entrega o quê?
```

---

## Case: Conteúdo Orgânico

**Contexto:** Final de 2023, mercado de nutracêuticos.

### O que todo mundo fazia:
- Pegava anúncios da biblioteca
- Modelava mudando palavras
- Mesma estrutura, mesmo formato, mesma comunicação

### Big Idea de Vitor Mound:
Pegar conteúdo **ORGÂNICO** do Instagram (experts falando de receitinhas naturais com milhões de views) e adaptar para anúncio pago.

### Por que era uma Big Idea:
- Comunicação completamente diferente (orgânica vs. publicitária)
- Formato diferente (estilo de conteúdo vs. estilo de anúncio)
- Prova social implícita (se viralizou orgânico, ressoa com o público)
- Zero concorrência inicial

### Resultado:
- Primeiro anúncio vendeu R$3-4 milhões em 15-20 dias
- Funcionou para múltiplos nichos: emagrecimento, diabetes, visão, memória
- Escalou até o mercado começar a replicar e saturar

---

## Template de Big Idea

```markdown
## BIG IDEA: [Nome/Título]

**Tese em 1 frase:**
> "[A frase que resume o conceito]"

**Pilares usados:**
- [ ] Perigo/Risco
- [ ] Underground/Segredo
- [ ] Conflito com Sistema
- [ ] Resultado Inesperado

**Por que funciona:**
1. [Razão 1]
2. [Razão 2]
3. [Razão 3]

**Hook derivado:**
> "[Primeira frase do criativo baseada na Big Idea]"

**Validação:**
- [ ] Curiosidade imediata?
- [ ] Conflito embutido?
- [ ] Emoção forte?
- [ ] Específica?
- [ ] Desejo do avatar?
- [ ] Verdadeira?
```

---

*Consolidado de: big-ideas-curiosas.md + Metodologia Vitor Mound (Seção 4) | v2.0 | 2026-01-26*
