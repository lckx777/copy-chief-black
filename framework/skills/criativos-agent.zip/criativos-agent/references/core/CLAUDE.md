# Core - Conhecimento Universal de Copy

> **Este diretório contém fundamentos UNIVERSAIS de psicologia e comunicação que se aplicam a TODA copy de Direct Response.**

## Quando Carregar

**SEMPRE** que a skill criativos-agent for ativada, estes arquivos devem ser consultados como base para qualquer criação ou análise.

## Arquivos

| Arquivo | Conteúdo | Prioridade |
|---------|----------|------------|
| `psicologia-humana.md` | 10 Gatilhos Reptilianos + 6 Necessidades + 5 Consciência + 5 Sofisticação + Progressão Emocional | CORE |
| `metodologia-hooks.md` | 3Ms + Anatomia Hook (Vitor Mound) + NUUPPECC + 4 Fortalecedores + Curiosity Gap | CORE |
| `estrutura-body.md` | 12 Blocos do Body + Disparos de Dopamina (Vitor Mound) + Sinestesia + Future Pacing | CORE |
| `big-ideas.md` | 4 Pilares + Ciclo de Vida (Vitor Mound) + Fórmulas + Cases | CORE |

## Ordem de Leitura Recomendada

1. **psicologia-humana.md** - Entender O QUE ativar (emoções, gatilhos, necessidades)
2. **metodologia-hooks.md** - Entender COMO capturar atenção (frameworks de hook)
3. **estrutura-body.md** - Entender COMO estruturar o corpo (blocos, disparos, pacing)
4. **big-ideas.md** - Entender COMO diferenciar (conceitos únicos)

## Metodologias Integradas

- **Framework Tradicional**: NUUPPECC, 3Ms, 4 Fortalecedores (Max Peters)
- **Metodologia Vitor Mound**: 3 Elementos Obrigatórios, Frases de Poder, Disparos de Dopamina, Ciclo de Vida Big Idea
- **Power Writing**: Curiosity Gap, Rhythm, Storytelling (Shaan/Sam)

---

*Última atualização: 2026-01-26 | Integração Metodologia Vitor Mound*
