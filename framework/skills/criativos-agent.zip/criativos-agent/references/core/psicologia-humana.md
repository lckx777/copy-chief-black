# Psicologia Humana para Direct Response

> **Fundamentos universais de comportamento humano que devem ser aplicados em TODA copy de Direct Response.**

## Sumário
1. [10 Gatilhos Reptilianos](#10-gatilhos-reptilianos)
2. [6 Necessidades Humanas Universais](#6-necessidades-humanas-universais)
3. [5 Níveis de Consciência](#5-níveis-de-consciência)
4. [5 Níveis de Sofisticação de Mercado](#5-níveis-de-sofisticação-de-mercado)
5. [6 Etapas de Progressão Emocional](#6-etapas-de-progressão-emocional)
6. [Aplicação em Criativos](#aplicação-em-criativos)

---

## 10 Gatilhos Reptilianos

O cérebro humano possui um hemisfério chamado **cérebro basal** ou **composto reptiliano**, responsável por instintos de sobrevivência, medo e resistência. Esses 10 gatilhos são **universais** — despertados em 100% das pessoas independente de vontade ou crenças.

### 1. PODER
Desejo de ter controle, influência e capacidade de impactar o ambiente.
> "Tenha o poder de decidir quando e onde trabalhar"
> "Domine sua saúde sem depender de médicos"

### 2. SEGURANÇA
Necessidade de proteção contra riscos e ameaças.
> "Proteja sua família de emergências financeiras"
> "Nunca mais se preocupe com contas no fim do mês"

### 3. CONTROLE
Desejo de ter domínio sobre a própria vida e situações.
> "Retome o controle do seu peso"
> "Você no comando da sua vida íntima"

### 4. ACEITAÇÃO SOCIAL
Necessidade de ser aceito e pertencer a grupos.
> "Finalmente ser admirado pela família"
> "Fazer parte do seleto grupo de pessoas bem-sucedidas"

### 5. LIBERDADE
Desejo de autonomia e independência.
> "Liberdade de comer o que quiser sem culpa"
> "Trabalhe de qualquer lugar do mundo"

### 6. SOBREVIVÊNCIA
Instinto mais básico de preservação.
> "Evite que sua diabetes evolua para amputação"
> "Salve sua vida antes que seja tarde"

### 7. RECONHECIMENTO
Desejo de ser valorizado e admirado.
> "Seja reconhecido como referência na sua área"
> "As pessoas vão notar a diferença em você"

### 8. BUSCA PELO PRAZER
Tendência natural de buscar recompensa e evitar dor.
> "Emagreça sem abrir mão dos prazeres da vida"
> "Sinta prazer em se olhar no espelho novamente"

### 9. DESCOBERTA / SEGREDOS
Curiosidade inata por conhecimento oculto.
> "O segredo que ninguém te contou sobre..."
> "Descubra o que estão escondendo de você"

### 10. HERANÇA FAMILIAR
Instinto de proteger e prover para a família/descendentes.
> "Garanta o futuro dos seus filhos"
> "Deixe um legado para sua família"

### Combinações Poderosas

| Combinação | Contexto Ideal |
|------------|----------------|
| Segurança + Herança | Produtos financeiros, saúde |
| Liberdade + Poder | Renda extra, empreendedorismo |
| Aceitação + Reconhecimento | Emagrecimento, beleza |
| Descoberta + Poder | Educação, desenvolvimento pessoal |
| Prazer + Liberdade | Lifestyle, wellness |
| Sobrevivência + Controle | Saúde, doenças crônicas |

### Gatilhos por Nicho

| Nicho | Primários | Secundários |
|-------|-----------|-------------|
| Emagrecimento | Aceitação Social, Reconhecimento, Prazer | Controle, Segurança, Poder |
| Disfunção Erétil | Poder, Reconhecimento, Prazer | Controle, Aceitação Social |
| Renda Extra | Liberdade, Segurança, Poder | Reconhecimento, Herança Familiar |
| Diabetes/Saúde | Sobrevivência, Segurança, Controle | Herança Familiar, Liberdade |
| Relacionamentos | Aceitação Social, Prazer, Reconhecimento | Poder, Segurança |
| Concursos | Segurança, Reconhecimento, Liberdade | Poder, Herança Familiar |

---

## 6 Necessidades Humanas Universais

Todo ser humano é movido por estas necessidades fundamentais:

### 1. Sobrevivência e Segurança
Necessidade mais básica: segurança física, financeira e emocional.

**Por nicho:**
- **Renda Extra:** Medo de dificuldades financeiras, não pagar contas, perder bens
- **Emagrecimento:** Medo de doenças graves (diabetes, hipertensão, problemas cardíacos)
- **Concursos:** Medo de instabilidade, desemprego, não conseguir sustentar família

### 2. Prazer e Conforto
Alívio de tensões, desfrutar bons momentos, evitar dores.

### 3. Aceitação e Pertencimento
Necessidade de fazer parte de grupo, família ou círculo social.

### 4. Reconhecimento e Status
Ser aceito, valorizado, admirado.

### 5. Liberdade e Independência
Autonomia sobre próprias decisões e vida.

### 6. Proteção e Cuidado
Proteger quem ama (família, filhos).

---

## 5 Níveis de Consciência

### 1. Inconsciente do Problema
Não percebe que tem um problema.
**Como comunicar:** Educar sobre a existência do problema.

### 2. Consciente do Problema
Sabe que tem problema mas não conhece soluções.
**Como comunicar:** Agitar a dor + mostrar que existe solução.
> "Você já tentou dietas, exercícios e até remédios para emagrecer, mas continua frustrado por não conseguir resultados duradouros?"

### 3. Consciente da Solução
Conhece algumas soluções mas não encontrou a ideal.
**Como comunicar:** Diferenciar sua solução das outras.
> "Ao contrário das dietas tradicionais, que restringem seu prazer alimentar e não funcionam a longo prazo, nosso método permite você emagrecer rápido, sem abrir mão dos alimentos que ama."

### 4. Consciente do Produto
Já ouviu falar do seu produto, precisa ser persuadido.
**Como comunicar:** Provas sociais, estudos, depoimentos, garantias.
> "Mais de 47 mil homens já recuperaram sua potência sexual com nosso suplemento natural aprovado pela Johns Hopkins University."

### 5. Consciente do Mecanismo (Most Aware)
Conhece produto E mecanismo. Quase pronto para comprar.
**Como comunicar:** Reforçar garantias, eliminar últimas dúvidas, dar empurrão final.
> "Você já sabe que nosso método exclusivo ativa o hormônio GLP-1. Agora, você tem uma garantia total de 180 dias para experimentar sem risco algum."

---

## 5 Níveis de Sofisticação de Mercado

*Conceito de Eugene Schwartz*

### Nível 1: Promessa Simples e Direta
Mercado virgem. Promessas simples funcionam.
> "Emagreça 7 kg em 7 dias."

### Nível 2: Promessa Expandida
Público já familiarizado. Adicionar benefícios extras, velocidade, facilidade.
> "Emagreça 7 kg em 7 dias, sem passar fome ou fazer exercícios intensos."

### Nível 3: Introdução de Mecanismo Único
Mercado conhece promessas comuns. Hora de explicar POR QUE funciona.
> "Emagreça 7 kg em 7 dias com o Método da Água Gelada, que acelera o metabolismo até 4x mais rápido."

### Nível 4: Mecanismo Expandido + Provas
Mercado saturado de mecanismos. Precisa de validação científica.
> "Novo estudo de Harvard revela que o Método da Água Gelada ativa o hormônio XYZ, queimando até 432 calorias extras por noite."

### Nível 5: Identificação/Personalização Profunda
Nível mais desafiador. Público ouviu tudo. Caminho é emocional e íntimo.
> "Como uma mãe de 45 anos, que já tinha tentado tudo, perdeu 7 kg em 7 dias usando o Método da Água Gelada — e como você pode fazer o mesmo."

### Como Identificar o Nível
1. Analisar promessas dos concorrentes (quão específicas/detalhadas são)
2. Observar reações do público (comentários, dúvidas, crenças)
3. Testar diferentes abordagens em anúncios curtos

---

## 6 Etapas de Progressão Emocional

Sequência emocional que leva à decisão de compra:

### Etapa 1: Desconforto Inicial
Incômodo vago, ainda não identificou o problema.
> **Emagrecimento:** Desconforto com roupas apertadas, cansaço constante.

### Etapa 2: Frustração Crescente
Percebe o problema, tentou soluções pontuais sem sucesso.
> **Emagrecimento:** Tentou dietas rápidas, academia sem resultado.

### Etapa 3: Desânimo Profundo
Tentou várias soluções, começa a aceitar que talvez não exista solução.
> **Emagrecimento:** Depois de várias dietas, acredita que nunca vai conseguir.

### Etapa 4: Esperança Renovada
**PONTO DE VIRADA.** Descobre nova abordagem/mecanismo diferente.
> **Emagrecimento:** Descobre método GLP-1, "Brazilian Mounjaro" — esperança volta.

### Etapa 5: Abertura Mental
Emocionalmente pronto para tentar novamente. Ainda há ceticismo, mas disposto.
> **Emagrecimento:** Mesmo com receio, disposto a tentar por causa das evidências.

### Etapa 6: Decisão de Compra
Convencido, toma ação.

---

## Aplicação em Criativos

### No Hook
- Ativar 1-2 **gatilhos reptilianos** principais que ressoam com o cluster
- Ativar **medos específicos** (curto/longo prazo)
- Desafiar **crenças limitantes**
- Prometer suprir **necessidade profunda**

### No Body
- Reforçar gatilhos através de storytelling
- Agitar a dor (Etapas 1-3 da progressão)
- Apresentar esperança (Etapa 4)
- Quebrar ceticismo (Etapa 5)
- Gerar ação (Etapa 6)

### No CTA
- Conectar ação imediata à satisfação do gatilho

### Por Nível de Sofisticação
- Nível 1-2: Promessa direta
- Nível 3: Introduzir mecanismo
- Nível 4: Adicionar provas
- Nível 5: Storytelling emocional

---

*Consolidado de: gatilhos-reptilianos.md + psicologia-nicho.md | v2.0 | 2026-01-26*
