# Estrutura do Body de Criativos

> **Frameworks e técnicas para construir o corpo do criativo que eleva consciência e leva à ação.**

## Sumário
1. [Visão Geral da Estrutura](#visão-geral-da-estrutura)
2. [12 Elementos do Body](#12-elementos-do-body)
3. [Disparos de Dopamina](#disparos-de-dopamina)
4. [Fluidez e Linguagem](#fluidez-e-linguagem)
5. [Sinestesia da Rotina](#sinestesia-da-rotina)
6. [Future Pacing Obrigatório](#future-pacing-obrigatório)
7. [Storytelling: Intention + Obstacle](#storytelling-intention--obstacle)
8. [Ritmo e Variação](#ritmo-e-variação)

---

## Visão Geral da Estrutura

```
┌─────────────────────────────────────────┐
│           FORMATO                       │
│  Embalagem visual que dispara dopamina  │
│  antes de uma palavra ser dita          │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│           HOOK (Gancho)                 │
│  Primeiros segundos - 80/20 do criativo │
│  Define qual público será atraído       │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│    FRASE DE TRANSIÇÃO                   │
│  Conecta hook ao body                   │
│  Ameniza ou continua a ideia            │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│           BODY (Corpo)                  │
│  - Aumenta consciência do problema      │
│  - Desvalida outras soluções            │
│  - "Hipnotiza" para descobrir mais      │
│  - USA ESTRUTURA INVISÍVEL              │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│           CTA                           │
│  Indireto → Direto                      │
│  Transfere toda euforia para o link     │
└─────────────────────────────────────────┘
```

### Funções Resumidas

| Parte | Função Principal |
|-------|------------------|
| FORMATO | Embalagem visual - parar scroll |
| HOOK | Ângulo + Emoção - definir público |
| BODY | Vender (se não vendeu, é culpa dele) |
| CTA | Transferir euforia para o link |

---

## 12 Elementos do Body

**NÃO existe ordem fixa.** Esses elementos são referências para combinar e adaptar com liberdade criativa conforme contexto e estratégia.

### 1. Reason Why
Explicação lógica pós-hook.
> "Se você engorda mesmo comendo pouco, provavelmente tem uma bactéria intestinal que bloqueia seu metabolismo."

### 2. Teasing MUP (Mecanismo do Problema)
> "Pesquisadores descobriram um parasita silencioso que faz mulheres acima de 40 anos acumular gordura no abdômen."

### 3. Teasing MUS (Mecanismo da Solução)
> "Essa fruta asiática ativa um hormônio que derrete gordura abdominal mesmo enquanto você dorme."

### 4. Quebra de Ceticismo
> "Sei que parece bom demais pra ser verdade, eu mesma duvidei, até ver os resultados na prática."

### 5. Reforço de Benefícios
> "Sua barriga vai começar a diminuir, suas roupas vão ficar folgadas, e as pessoas vão notar rapidamente a diferença."

### 6. Credibilidade/Autoridade
> "Dr. Oz revelou em seu programa exatamente essa receita caseira que faz perder até 5 kg em 7 dias."

### 7. Comparação/Superação
> "Esse chá japonês tem o mesmo efeito da bariátrica, mas sem precisar de cirurgia ou dietas radicais."

### 8. Quebra de Objeções
> "E não se preocupe, você não precisa abandonar doces ou carboidratos que você tanto gosta."

### 9. Detalhamento/Prova Científica
> "Cientistas da Harvard descobriram que esse ingrediente bloqueia diretamente a absorção de açúcar no intestino."

### 10. Escassez/Urgência
> "Mas atenção, esse vídeo pode sair do ar nas próximas 24 horas."

### 11. Future Pacing
> "Imagine você acordando amanhã com mais energia, disposição, barriga mais lisa e roupas mais folgadas."

### 12. CTA Final
> "Clique no botão abaixo agora mesmo para aprender exatamente como fazer isso."

---

## Disparos de Dopamina

### Definição
Disparos de dopamina são frases estrategicamente inseridas no meio do body que quebram a monotonia explicativa e reengajam o espectador. Funcionam como "mini-hooks" distribuídos ao longo do criativo.

### O Problema que Resolvem
Todo anúncio tem partes "chatas" necessárias:
- Explicação do mecanismo
- Modo de uso
- Ingredientes/componentes
- Detalhes técnicos

Essas partes são necessárias para a conversão, mas entediantes. O lead pode desengajar durante elas.

### O Efeito "What The Fuck"
A característica principal do disparo de dopamina é que ele **não precisa ser 100% congruente** com o fluxo lógico do texto naquele momento.

Ele interrompe propositalmente o raciocínio para gerar uma reação de "ué, que que é isso?" — e essa interrupção **PRENDE** a pessoa no anúncio.

É contra-intuitivo: a quebra de fluxo que parece "errada" é exatamente o que funciona.

### 3 Tipos de Disparos de Dopamina

#### Tipo 1: Projeção de Futuro Desejável
Frases que fazem o lead visualizar o resultado emocional/social do produto.

**Exemplos:**
- "...e as calças vão ficar folgadas."
- "Meu marido vai ficar com ciúme de mim."
- "Todo mundo que passar na rua vai virar os olhos."
- "Suas amigas vão perguntar o que você está fazendo."
- "Você vai precisar de um guarda-roupa novo."

#### Tipo 2: Fascinations/Bullets Impactantes
Mini-promessas específicas inseridas no meio do texto.

**Exemplos:**
- "...e o melhor: sem passar fome."
- "Funciona mesmo enquanto você dorme."
- "E você pode comer o que quiser."

#### Tipo 3: Loops de Curiosidade Internos
Pequenas aberturas de curiosidade que serão "fechadas" mais adiante.

**Exemplos:**
- "Mas tem um detalhe crucial que vou explicar..."
- "E aí vem a parte que ninguém fala..."
- "Só que tem um porém..."

### Posicionamento Estratégico

**Onde inserir disparos de dopamina:**

1. **Após explicação de mecanismo:** O mecanismo é técnico e pode entediar. Insira um disparo logo depois.

2. **No meio de listas/ingredientes:** Se você precisa listar vários itens, quebre com um disparo no meio.

3. **Antes de seções "burocráticas":** Modo de uso, garantia, etc. O disparo prepara para manter atenção.

4. **Quando o texto passou 30+ segundos sem elemento emocional:** Regra geral — não deixe muito tempo sem reativar emoção.

### Exemplo de Aplicação

**Texto SEM disparo de dopamina:**
> "Esse chá contém gengibre, limão e canela. Você deve tomar toda manhã em jejum. O gengibre acelera o metabolismo, o limão desintoxica e a canela regula a glicose."

**Texto COM disparo de dopamina:**
> "Esse chá contém gengibre, limão e canela. Você deve tomar toda manhã em jejum. *E as calças vão começar a ficar folgadas logo na primeira semana.* O gengibre acelera o metabolismo, o limão desintoxica e a canela regula a glicose."

---

## Fluidez e Linguagem

### Tom de WhatsApp — NÃO de documento

| PROIBIDO | USAR |
|----------|------|
| "inconsistente", "impreciso" | "bugada", "travada" |
| "Pesquisadores afirmam..." | "descobriram que..." |
| "E sabe por quê isso acontece?" | (cortar — ir direto) |
| Parágrafos 4+ linhas | Frases curtas, máx 12 palavras |

### Teste de Validação
**PowerPoint? Reescrever. Desabafo no bar? Certo.**

### Blocos Conectados (Sem Quebras)

Cada bloco = UMA intenção clara. Transições invisíveis entre blocos.

| PROIBIDO | FAZER |
|----------|-------|
| Mudar de assunto do nada | Transição natural e invisível |
| "Mas voltando ao assunto..." | Fluxo contínuo |
| Quebra de tom ou persona | Mesmo tom do início ao fim |

---

## Sinestesia da Rotina

O avatar deve SE VER na copy. Usar rotina REAL:

| Genérico (PROIBIDO) | Sinestesia Real (USAR) |
|---------------------|------------------------|
| "cansada" | "chegar em casa e só querer deitar no sofá" |
| "preocupada com dinheiro" | "olhar pro app do banco e sentir aquele aperto" |
| "frustrada com dieta" | "se olhar no espelho do banheiro e não se reconhecer" |
| "ansioso com prova" | "acordar às 3h da manhã pensando na prova" |
| "estressado no trabalho" | "chegar em casa e descontar nos filhos" |

---

## Future Pacing Obrigatório

Fazer avatar VISUALIZAR e SENTIR o resultado:

| Genérico (PROIBIDO) | Future Pacing Real (USAR) |
|---------------------|---------------------------|
| "Você vai ter mais energia" | "acordar antes do despertador, sem aquela moleza" |
| "Vai emagrecer" | "vestir aquela calça que tá no fundo do armário" |
| "Ser mais confiante" | "entrar na reunião e falar sem a voz tremer" |
| "Ter mais dinheiro" | "abrir o app do banco e sorrir pela primeira vez" |
| "Passar no concurso" | "ver seu nome na lista e ligar pro seu pai" |

**Fórmula:** Momento específico + Sensação física + Ação concreta + Contraste implícito

---

## Storytelling: Intention + Obstacle

> "Eu venero no altar de INTENÇÃO e OBSTÁCULO." — Aaron Sorkin

| Elemento | Definição | Exemplo |
|----------|-----------|---------|
| **INTENÇÃO** | O que o personagem quer | Cara quer emagrecer |
| **OBSTÁCULO** | O que está no caminho | Toxina bloqueia metabolismo |
| **STAKES** | O que está em jogo | Saúde, autoestima |

**Teste:** Pause em qualquer momento. Você sabe o que o personagem quer e o que impede? Se não, reescreva.

### High Stakes in Low Stakes

A arte é criar ALTAS APOSTAS EMOCIONAIS em SITUAÇÕES DE BAIXA APOSTA.

- Situação: alguém cortou a fila no mercado (baixa aposta)
- Emoção: se você faz o leitor sentir a indignação (alta aposta emocional)

**Por que funciona:** Histórias relacionáveis multiplicam impacto.

---

## Ritmo e Variação

**Erro:** Todas as frases do mesmo tamanho.

**Solução:** Variar comprimento para criar música.

```
Esta frase tem cinco palavras.
Aqui estão mais cinco palavras.
Frases curtas são ok.
Mas várias juntas ficam monótonas.
O ouvido cansa.

Agora ouça.
Eu vario o comprimento e crio música.
A escrita canta.
Tem ritmo, melodia, harmonia.
Uso frases curtas.
E uso médias.
E às vezes, quando o leitor está descansado,
eu o envolvo com uma frase longa que queima com energia
e cresce como um crescendo — sons que dizem:
ouça isso, isso é importante.
```

**Regra:** Curto por padrão. Longo para impacto quando leitor está "descansado".

---

## Checklist de Body

### ESTRUTURA
```
□ Tem MUP (Mecanismo do Problema)?
□ Tem MUS (Mecanismo da Solução)?
□ Tem quebra de ceticismo?
□ Tem prova/credibilidade?
□ Tem future pacing?
□ CTA em duas etapas (indireto → direto)?
```

### DISPAROS DE DOPAMINA
```
□ Inseriu após explicação de mecanismo?
□ Inseriu no meio de listas técnicas?
□ Não passou 30s sem elemento emocional?
```

### FLUIDEZ
```
□ Tom de WhatsApp (não PowerPoint)?
□ Frases curtas (máx 12 palavras)?
□ Ritmo variado (curto + médio + longo)?
□ Transições invisíveis entre blocos?
```

### SINESTESIA
```
□ Avatar se vê na copy?
□ Usou rotina real (não genérica)?
□ Future pacing é sensorial (não abstrato)?
```

---

*Consolidado de: estrutura-criativos.md + Metodologia Vitor Mound (Seção 3) | v2.0 | 2026-01-26*
