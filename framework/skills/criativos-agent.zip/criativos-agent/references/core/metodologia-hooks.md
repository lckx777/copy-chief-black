# Metodologia de Hooks para Direct Response

> **Frameworks e técnicas para criar hooks que capturam atenção e geram curiosidade irresistível.**

## Sumário
1. [3Ms — Núcleo de Big Ideas](#3ms--núcleo-de-big-ideas)
2. [Anatomia do Hook (Vitor Mound)](#anatomia-do-hook-vitor-mound)
3. [NUUPPECC — 8 Atributos de Atenção](#nuuppecc--8-atributos-de-atenção)
4. [4 Fortalecedores de Hooks](#4-fortalecedores-de-hooks)
5. [Frases de Poder](#frases-de-poder)
6. [Curiosity Gap](#curiosity-gap)
7. [Case Prático: Água com Limão](#case-prático-água-com-limão)

---

## 3Ms — Núcleo de Big Ideas

Todo criativo de alta conversão precisa de três pilares:

| Pilar | Função | Pergunta-Guia |
|-------|--------|---------------|
| **MISTÉRIO** | Diferenciação automática | Qual termo único de 1-3 palavras "esconde" o método? |
| **MECANISMO** | Invalidação de alternativas | Por que o prospect falhou antes e terá sucesso agora? |
| **MERCADO** | Validação de demanda | Existe público ativo buscando essa solução? |

**Sequência correta:** MERCADO → MECANISMO → MISTÉRIO

### Exemplos de Mistério (Gimmick Names)

| Genérico | Com Mistério |
|----------|--------------|
| Gotas emagrecedoras | "Ozempic Natural" |
| Curso de IA para concursos | "GPT dos Aprovados" |
| Método de vendas | "Marketing de Conversa" |
| Investimentos no exterior | "Investimentos Nômades" |

**Regra:** O Mistério deve gerar curiosidade + carregar a promessa implícita.

---

## Anatomia do Hook (Vitor Mound)

### Os 3 Elementos Obrigatórios

Todo hook eficaz precisa conter três elementos trabalhando simultaneamente:

| Elemento | Função | Erro Fatal |
|----------|--------|------------|
| **QUALIFICAÇÃO** | Filtrar público certo | "Vocês não vão acreditar" (não filtra ninguém) |
| **EMOÇÃO** | Ativar estado emocional | Hook neutro (não incomoda) |
| **CURIOSIDADE** | Criar loop aberto | Revelar tudo no hook |

#### 1. QUALIFICAÇÃO
O hook precisa filtrar o público certo. Não é chamar atenção por chamar atenção.

**Formas de qualificar no hook:**
- Mencionar o problema diretamente ("barriga inchada", "glicose alta")
- Usar o nome chiclete do mecanismo ("truque do limão congelado")
- Citar superestrutura conhecida do nicho (ex: "Monjaro", "Ozempic")
- Usar palavras-gatilho específicas do nicho ("emagrecer", "diabetes", "memória")

#### 2. EMOÇÃO
Todo hook deve transmitir uma emoção específica. Hooks neutros não funcionam.

**Emoções que funcionam:**
- Medo
- Nojo
- Raiva
- Sarcasmo
- Indignação
- Choque
- Curiosidade intensa
- Descrença

**Objetivo:** Incomodar. Se o lead passou pelo hook "de boa", o hook **FALHOU**.

#### 3. CURIOSIDADE
O hook deve criar uma lacuna de informação que só será preenchida se continuar assistindo.

**A curiosidade vem de:**
- Informação incompleta ("o que ninguém te conta sobre...")
- Contradição ("isso que você faz todo dia está te engordando")
- Promessa de revelação ("descobri por que...")
- Especificidade intrigante ("perdi 12kg com algo que custa R$3")

### Hierarquia de Informação

**Princípio:** A informação mais importante e curiosa deve vir PRIMEIRO na frase.

❌ **Erro:**
> "Minha mãe ficou em choque depois que eu usei água e limão para emagrecer."

✅ **Correto:**
> "Eu usei água e limão para emagrecer e minha mãe ficou em choque."

**Por que funciona:** O elemento de maior curiosidade é "água e limão para emagrecer", não "minha mãe". Nos primeiros milissegundos, o cérebro processa o início da frase.

### O Erro do "Isso Aqui"

❌ **Não funciona:**
> "Eu usei ISSO AQUI para emagrecer."
> "Faça ISSO todo dia."
> "Descobri ISSO e mudou minha vida."

✅ **Funciona:**
> "Eu usei o TRUQUE DO GENGIBRE CONGELADO para emagrecer."
> "Faça o RITUAL DO VINAGRE todo dia."
> "Descobri o MÉTODO JAPONÊS e mudou minha vida."

**Regra:** Se existe um nome chiclete para o mecanismo, ele DEVE estar no hook.

---

## NUUPPECC — 8 Atributos de Atenção

Quanto mais atributos no hook, mais atenção captura:

| Letra | Atributo | Exemplo |
|-------|----------|---------|
| **N** | Novo | "Descoberta de 2024..." |
| **U** | Urgente | "Antes que tirem do ar..." |
| **U** | Único | "O único método que..." |
| **P** | Perigoso | "Quase fui preso..." |
| **P** | Pessoal | "Se você é mulher acima de 40..." |
| **E** | Específico | "Em 47 dias..." / "R$8M em 10 meses" |
| **C** | Concreto | "Minha calça ficou folgada" |
| **C** | Controverso | "Sem mostrar a cara, sem fazer conteúdo" |

### Teste de Headline

❌ Genérico:
> "Como criar infoprodutos de sucesso"

✅ Com NUUPPECC:
> "O método que usamos para ir de 0 a 8M em 10 meses — sem mostrar nossa cara, fazer conteúdos ou usar fórmula de lançamento"

**Mínimo:** 4 atributos NUUPPECC por hook.

---

## 4 Fortalecedores de Hooks

Amplificadores que podem ser combinados:

### 1. INESPERADO
Quebra padrões mentais do leitor.
> "Eu tirei meu dinheiro do Brasil e coloquei nesses 4 países — e no segundo mês já tinha um segundo salário."

### 2. CONCRETO
Detalhes visuais e sensoriais.
> "Tá vendo esse apartamento? Eu moro de aluguel nele, mas não tiro um centavo do meu bolso pra isso..."

### 3. CRÍVEL
Provas sociais ou autoridades externas.
> "O governo dos EUA acabou de investir X bilhões nesse ativo que estão chamando de investimentos nômades."

### 4. ESCASSO
Urgência legítima com janela temporal.
> "Vou te mostrar como aproveitar isso até dezembro."

**Fórmula:** Hook forte = 2-3 fortalecedores combinados.

---

## Frases de Poder

Construções linguísticas que amplificam o impacto de qualquer afirmação subsequente.

### Mecanismo
As frases de poder funcionam criando uma "preparação psicológica" antes da informação principal. Isso ativa:
- Estado de alerta aumentado
- Curiosidade antecipatória
- Sensação de acesso privilegiado
- Percepção de autenticidade/vulnerabilidade

### Catálogo de Frases de Poder

**Categoria: Informação Oculta**
- "Vou te contar o que nunca te falaram sobre..."
- "O que ninguém tem coragem de dizer é que..."
- "Existe algo que os médicos não contam..."
- "O segredo que a indústria esconde é..."

**Categoria: Risco Pessoal**
- "Posso ser cancelado por falar isso, mas..."
- "Vão me odiar por revelar isso, mas..."
- "Isso pode me dar problemas, mas..."
- "Nunca falei isso publicamente, mas..."

**Categoria: Contradição/Quebra de Expectativa**
- "Isso vai ser contraditório, mas..."
- "Parece loucura, mas..."
- "Eu sei que vai soar estranho, mas..."
- "Contra tudo que você já ouviu..."

**Categoria: Vulnerabilidade/Honestidade**
- "Vou ser honesta com você..."
- "Preciso confessar uma coisa..."
- "A verdade que eu escondi por anos..."
- "Tenho vergonha de admitir, mas..."

**Categoria: Urgência/Escassez**
- "Essa é a última vez que vou falar sobre..."
- "Antes que removam esse vídeo..."
- "Enquanto ainda posso compartilhar..."

**Categoria: Exclusividade**
- "O que vou mostrar agora, poucos sabem..."
- "Isso aqui não está em nenhum lugar..."
- "Pela primeira vez estou revelando..."

### Aplicação Prática

**Método:**
1. Escreva seu hook original
2. Identifique qual categoria de frase de poder se encaixa
3. Adicione a frase de poder ANTES do hook
4. Ajuste a fluidez da transição

**Exemplo de transformação:**

*Hook original:*
> "Água com limão não emagrece."

*Com frase de poder (Risco Pessoal):*
> "Posso ser cancelada por falar isso, mas água com limão não emagrece."

*Com frase de poder (Informação Oculta):*
> "O que ninguém tem coragem de te dizer: água com limão não emagrece."

---

## Curiosity Gap

### Teste da Mão
1. Cubra todo o texto exceto as 2 primeiras frases
2. Pergunte: "Eu PRECISO ler a próxima frase?"
3. Se sim, desça a mão e repita
4. Se não, reescreva

**Princípio:** Cada frase deve criar a necessidade de ler a próxima.

### Don't Bury The Lead

❌ ERRADO:
> "Nos últimos dias tenho refletido sobre um experimento que decidi fazer. Para contextualizar, meu nome é Steve..."

✅ CERTO:
> "Passei os últimos 30 dias comendo apenas Soylent. Por que eu faria algo tão estúpido? Já explico."

**Hack:** Corte os primeiros parágrafos. A última frase do que cortou provavelmente é seu verdadeiro lead.

---

## Case Prático: Água com Limão

**Contexto:** Hook amplamente usado no mercado de emagrecimento.

### Hook Original (Saturado)
> "Não beba água com limão se você quiser emagrecer."

**Análise:**
- Qualifica: Sim (emagrecimento)
- Gera curiosidade: Sim (contradição)
- Transmite emoção: **Fraca** (apenas surpresa leve)

**Problema:** Todo mundo estava usando variações desse hook. Sem diferenciação emocional.

### Hook Reconstruído (Vitor Mound)
> "Essa mentira é clássica, né? Beber água com limão emagrece. Parece piada."

**Análise:**
- Qualifica: Sim (emagrecimento + água com limão)
- Gera curiosidade: Sim (por que é mentira?)
- Transmite emoção: **FORTE** (sarcasmo, faz quem acredita se sentir provocado)

**Por que escalou:** O tom sarcástico criou uma reação emocional que o hook original não tinha. A pessoa que toma água com limão se sente provocada. Isso gera engajamento (mesmo que negativo inicialmente).

**Por que ninguém conseguiu bater o controle:** Os modeladores copiavam as palavras sem entender a psicologia. Tiravam o sarcasmo, mudavam o tom, destruíam o mecanismo emocional.

---

## Checklist Unificado de Hooks

### ANTES DE ESCREVER
```
□ Defini os 3Ms (Mistério, Mecanismo, Mercado)?
□ Defini REAÇÃO (emoção) + AÇÃO (clique)?
□ Consultei swipe file para referências?
```

### AO ESCREVER
```
□ Hook tem os 3 elementos obrigatórios (Qualificação + Emoção + Curiosidade)?
□ Hook tem 4+ atributos NUUPPECC?
□ Hook usa 2-3 fortalecedores combinados?
□ Informação mais importante vem primeiro (hierarquia)?
□ Tem nome chiclete (não usa "isso aqui")?
□ Considerei adicionar frase de poder?
```

### DEPOIS DE ESCREVER
```
□ Passa no Teste da Mão (curiosity gap)?
□ Lead não está enterrado?
□ Se o lead passar "de boa", REESCREVER
```

---

*Consolidado de: criatividade-hooks.md + Metodologia Vitor Mound (Seções 1-2) | v2.0 | 2026-01-26*
