# Ângulos e Hooks Validados

> **Biblioteca de ângulos testados e validados para criativos de Direct Response.**

---

## Sumário

1. [Tipos de Impacto Emocional](#tipos-de-impacto-emocional)
2. [15 Ângulos Validados](#15-ângulos-validados)
3. [Combinação de Ângulos](#combinação-de-ângulos)
4. [Super Estrutura do Mecanismo Único](#super-estrutura-do-mecanismo-único)

---

## Tipos de Impacto Emocional

Todo hook precisa de impacto emocional. Os 4 tipos principais:

### 1. Benefício Explícito
Vantagem clara e imediata.
> "Perca 3kg por semana tomando este chá bariátrico."
> "Faça sua glicemia cair 50 pontos em apenas 48 horas usando esta mistura."

### 2. Benefício Implícito
Dedução imediata sem ser dito diretamente.
> "Comi pizza e chocolate toda semana e ainda assim meus níveis de açúcar caíram de 200 para 90."
> (Implícito: controlar diabetes sem abrir mão das comidas favoritas)

### 3. Choque/Surpresa
Afirmação que provoca espanto imediato.
> "Metformina é pior que veneno para diabéticos se usado dessa forma."
> "Você sabia que Ozempic é puro veneno?"

### 4. Medo/Perigo
Emoção de alerta ou urgência sobre algo temido.
> "Um simples machucado quase fez meu marido diabético perder a perna."
> "Se você é diabético e sua visão está embaçada, cuidado: seu corpo já começou a entrar em colapso."

---

## 15 Ângulos Validados

### 1. PERGUNTA PARADOXAL
Pergunta que desafia lógica ou crença popular, criando paradoxo.

**Exemplos:**
> "Por que comer mais gordura pode fazer você emagrecer mais rápido do que cortar calorias?"
> "Se exercício físico emagrece, por que pessoas que fazem academia todos os dias ainda lutam contra a balança?"

---

### 2. NOVA DESCOBERTA
Revela algo novo, inédito ou recentemente descoberto.

**Exemplos:**
> "Pesquisadores de Stanford acabam de descobrir um hormônio que pode ser a chave para emagrecer até 10kg em um mês."
> "Novo estudo revela que essa raiz milenar japonesa aumenta naturalmente os níveis de GLP-1 no corpo."

---

### 3. MECANISMO DO PROBLEMA (MUP)
Expõe causa oculta ou inesperada do problema.

**Exemplos:**
> "Cientistas de Harvard descobriram uma toxina escondida nos intestinos que pode ser a verdadeira causa de você não conseguir emagrecer."
> "A razão pela qual você não perde peso pode ser uma bactéria intestinal específica que bloqueia 90% da queima de gordura."

---

### 4. MECANISMO DA SOLUÇÃO (MUS)
Revela como a solução funciona de forma específica.

**Exemplos:**
> "Essa fruta asiática ativa naturalmente seu GLP-1, o mesmo hormônio usado por celebridades para perder peso rapidamente."
> "Esse chá japonês acelera seu metabolismo em até 400% enquanto você dorme."

---

### 5. CONSPIRAÇÃO
Cria ideia de algo sendo escondido (cria "nós vs eles").

**Exemplos:**
> "Por que os médicos não falam sobre esse remédio natural que elimina diabetes em 3 semanas?"
> "A indústria farmacêutica não quer que você saiba: esse truque simples pode acabar com sua dependência de Metformina."

---

### 6. ERRO COMUM
Revela erro que público comete inconscientemente.

**Exemplos:**
> "Se você está tomando café da manhã diariamente achando que isso ajuda a emagrecer, você precisa ver isso."
> "Cortar carboidratos pode estar destruindo seu metabolismo: esse é o erro que 90% das pessoas cometem."

---

### 7. ANTES E DEPOIS
Mostra transformação visual/emocional impactante.

**Exemplos:**
> "Essa mulher perdeu 18kg em dois meses apenas usando essa receita simples todas as manhãs."
> "Ele tinha 130kg e diabetes descontrolada. Hoje pesa 85kg e aboliu a Metformina completamente."

---

### 8. PROVA SOCIAL / AUTORIDADE
Usa autoridade ou prova social forte.

**Exemplos:**
> "A dieta que a Oprah usou para perder 20kg finalmente revelada."
> "Dr. Oz revelou em seu programa que essa planta pode ser a solução para controlar diabetes sem remédios."

---

### 9. SEGREDO ANTIGO
Revela algo antigo ou secreto (mistério + exclusividade).

**Exemplos:**
> "Esse ritual japonês de 5.000 anos foi redescoberto como a chave para emagrecer naturalmente."
> "Mulheres francesas usam esse ingrediente secreto há séculos para nunca precisarem de dieta."

---

### 10. FOOD HACK
Apresenta truque simples usando alimento comum.

**Exemplos:**
> "Adicione isso ao seu café da manhã e veja sua barriga desinchar em poucos dias."
> "Beba esse chá com casca de banana antes de dormir e acorde mais magra no dia seguinte."

---

### 11. COMPARAÇÃO SUPERIOR
Compara solução com alternativas conhecidas mostrando superioridade.

**Exemplos:**
> "Esse truque caseiro faz o mesmo que a bariátrica, mas sem cirurgia ou efeitos colaterais."
> "Funciona como Ozempic, mas é 100% natural e não precisa de receita."

---

### 12. FOFOCA
Utiliza celebridade/personalidade de forma curiosa.

**Exemplos:**
> "Sabia que Angelina Jolie revelou que usava este creme caseiro porque tinha vergonha das manchas escuras nas mãos?"
> "O truque de beleza que Jennifer Aniston escondeu por anos foi finalmente revelado."

---

### 13. ALERTA URGENTE
Gera urgência imediata com tom de alerta.

**Exemplos:**
> "ALERTA: Não coma ovos se você tem mais de 50 anos..."
> "Se você é diabético, pare de tomar Metformina até ver isso."

---

### 14. INVERSÃO DE CRENÇA
Inverte completamente uma crença popular.

**Exemplos:**
> "E se eu te dissesse que comer mais vezes ao dia pode estar sabotando seu emagrecimento?"
> "Academias não emagrecem: a ciência finalmente provou isso."

---

### 15. DOR OCULTA
Revela dor emocional específica e escondida.

**Exemplos:**
> "Você sabe aquele medo silencioso de olhar no espelho e não se reconhecer mais?"
> "A vergonha de não conseguir acompanhar seus filhos pequenos por causa do cansaço extremo."

---

## Combinação de Ângulos

Você pode combinar múltiplos ângulos no mesmo hook para maior impacto.

### Exemplos de Combinações Validadas

| Combinação | Exemplo |
|------------|---------|
| **Food Hack + Antes e Depois** | "Essa receita rápida de maçã com canela fez essa mulher perder 17kg de gordura abdominal em poucas semanas." |
| **Segredo Antigo + MUS** | "Mulheres japonesas usam secretamente este chá milenar que acelera o metabolismo em 400% enquanto dormem." |
| **Fofoca + Dor Oculta** | "Sabia que Angelina Jolie revelou que usava este creme caseiro porque tinha vergonha das manchas escuras nas mãos?" |
| **Nova Descoberta + Comparação** | "Cientistas acabam de descobrir uma molécula que funciona como Ozempic, mas é 100% natural." |
| **Conspiração + Erro Comum** | "Os médicos sabem disso mas não falam: o erro que 90% dos diabéticos cometem com insulina." |
| **MUP + Prova Social** | "Harvard descobriu a toxina que travava o emagrecimento de 47.000 mulheres estudadas." |

---

## Super Estrutura do Mecanismo Único

### As 4 Camadas

| Camada | Descrição | Exemplo |
|--------|-----------|---------|
| **1. Ingrediente Hero** | Ingrediente principal que resolve a causa | Berberina, Sal Rosa, Casca de Banana |
| **2. Gimmick Name** | Nome "chiclete" relacionado ao ingrediente | Pink Salt Trick, Truque da Banana, Baking Soda Hack |
| **3. Origin Story** | De onde veio (credibilidade + curiosidade) | "Receita famosa entre atrizes de Hollywood" |
| **4. Authority Hook** | Gancho de autoridade derivado da origin | "Ozempic Natural", "Truque do FBI", "Truque do Cavalo" |

### Fórmula do Gancho da Solução

```
"Já ouviu falar desse [GIMMICK NAME] que [ORIGEM] estão usando secretamente para [DESEJO]? Já estão chamando isso de [AUTHORITY HOOK]."
```

### Exemplos Aplicados

> "Já ouviu falar desse Pink Salt Trick que atrizes de Hollywood estão usando para secar gordura na barriga? Chamam de Ozempic Natural."

> "Já ouviu falar desse Baking Soda Hack que atores pornôs usam para ereções como aos 20 anos? Chamam de Truque do Cavalo."

### Por Que Funciona

**Curiosidade + Prova simultânea:**
- "Como assim do cavalo?" (curiosidade)
- Cavalo = símbolo de potência (prova implícita)

> Gimmick Name gera curiosidade misturada com prova — irresistível.

---

## Regras Críticas para Ângulos

1. **Hook curto, forte e direto** - Não fazer hooks longos
2. **Pode combinar ângulos** - Não ficar preso a 1 só
3. **Impacto emocional obrigatório** - Sem emoção não funciona
4. **Paradoxo gera curiosidade** - Contradição atrai atenção
5. **Gimmick Name > nome genérico** - Cria propriedade e memorabilidade

---

## Índice Rápido de Ângulos

| # | Ângulo | Gatilho Principal |
|---|--------|-------------------|
| 1 | Pergunta Paradoxal | Curiosidade |
| 2 | Nova Descoberta | Novidade |
| 3 | MUP | Revelação |
| 4 | MUS | Esperança |
| 5 | Conspiração | Indignação |
| 6 | Erro Comum | Medo de perder |
| 7 | Antes e Depois | Prova visual |
| 8 | Prova Social | Credibilidade |
| 9 | Segredo Antigo | Mistério |
| 10 | Food Hack | Simplicidade |
| 11 | Comparação Superior | Desejo |
| 12 | Fofoca | Curiosidade |
| 13 | Alerta Urgente | Urgência |
| 14 | Inversão de Crença | Choque |
| 15 | Dor Oculta | Empatia |

---

*Migrado de: angulos-hooks.md | v1.0 | 2026-01-26*
