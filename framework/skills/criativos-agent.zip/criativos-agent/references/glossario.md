# Glossário Técnico de Criativos

> **Termos e conceitos usados em criativos de Direct Response.**

---

## A

**Authority Hook**
Gancho de autoridade que valida o mecanismo via **SUPER ESTRUTURA**. É o "apelido" que o mercado dá, referenciando algo conhecido.
- **Exemplos:** "Monjaro Natural" (ref. medicamento), "Truque do FBI" (ref. instituição), "Método Harvard"
- **DISTINÇÃO:** Authority Hook ≠ Gimmick Name. Authority está na super estrutura, Gimmick está no ingrediente.
- **Tipos fortes:** Referência a medicamento, instituição reconhecida, celebridade/elite
- **Ref:** Ver "Gimmick Name", "Origin Story"

**Avatar**
A pessoa que aparece no anúncio falando ou demonstrando. Deve ser congruente com o público-alvo.

**Ângulo**
Abordagem estratégica da mensagem (COMO a copy é passada). Ex: Nova Descoberta, Paradoxo, Conspiração.

---

## B

**Big Idea**
Conceito central único que diferencia o anúncio de todos os outros. Não é estrutura nem ângulo — é a IDEIA fundamental.

**Body**
Corpo do anúncio, tudo que vem depois do hook. Responsável por elevar consciência e levar à ação.

**Bullet/Fascination**
Mini-promessa específica e intrigante. Usado como disparo de dopamina ou em listas de benefícios.

---

## C

**Congruência**
Alinhamento total entre todos os elementos do anúncio (avatar, cenário, tom, edição, visual). Gera credibilidade.

**Controle**
Anúncio vencedor atual que serve como benchmark para testes. O objetivo é "bater o controle".

**CTA (Call to Action)**
Chamada para ação no final do anúncio. Ideal em duas etapas: indireto → direto.

**Curiosity Gap**
Lacuna de informação que prende o leitor. Cada frase deve criar necessidade de ler a próxima.

---

## D

**Disparo de Dopamina**
Frase estratégica que quebra monotonia e reengaja no meio do body. Tipos: Projeção de Futuro, Fascination, Loop Interno.

---

## E

**Elemento Acidental**
Parte do anúncio que pode ser mudada sem afetar a performance. Pode testar variações.

**Elemento Essencial**
Parte do anúncio que não deve ser alterada (validada pelo mercado). Ex: benefício principal, MUP, prova.

---

## F

**Formato**
Embalagem visual/audiovisual do criativo (o que a pessoa VÊ). Ex: UGC, Podcast, Tela Dividida, Green Screen.

**Frase de Poder**
Construção linguística que amplifica o impacto de afirmações subsequentes. Ex: "Posso ser cancelado por falar isso, mas..."

**Future Pacing**
Técnica de fazer o lead visualizar o futuro com o resultado. Deve ser sensorial e específico, não genérico.

---

## G

**Gimmick Name**
Nome chiclete de 1-3 palavras relacionado ao **INGREDIENTE HERO** (não ao sistema/método). Gera curiosidade instantânea.
- **Fórmula:** [Substantivo do Ingrediente] + [Trick/Hack/Truque]
- **Exemplos:** "Pink Salt Trick" (ingrediente: sal rosa), "Truque da Banana" (ingrediente: banana)
- **DISTINÇÃO:** Gimmick Name ≠ Authority Hook. Gimmick está no ingrediente, Authority está na super estrutura.
- **Ref:** Ver "Ingrediente Hero", "Authority Hook"

---

## H

**Hook/Gancho**
Primeiros segundos/frases do anúncio que capturam atenção. Representa 80/20 do criativo.

---

## I

**Ingrediente Hero**
O componente PRINCIPAL que resolve a nova causa. Em suplementos é a substância; em educação é a técnica core; em relacionamento é o protocolo principal.
- **Exemplos:** Pink Salt (suplemento), Decodificador de Paráfrases (concursos), Técnica do Espelho (relacionamento)
- **Uso:** O Gimmick Name deve ser criado A PARTIR do ingrediente hero.

**Indutor do Mecanismo**
O MÉTODO ou PRODUTO que ativa o mecanismo. É o que o cliente compra. Sinônimo de "Método" ou "Sistema".
- **Exemplo:** SFAP (Sistema de Fluência Automática de Português)
- **Ref:** Ver "MUS"

---

## L

**Hook/Gancho**
Primeiros segundos/frases do anúncio que capturam atenção. Representa 80/20 do criativo.

---

## L

**Lead**
Potencial cliente que está vendo o anúncio. Também: primeira parte do texto que "puxa" o leitor.

---

## M

**Modelagem**
Processo de criar anúncios baseados em referências que já funcionam. Diferente de Big Idea (criar algo novo).

**MUP (Mecanismo Único do Problema)**
Explicação única de POR QUE o problema existe. O que causa a dor do avatar.

**MUS (Mecanismo Único da Solução)**
Explicação única de POR QUE a solução funciona. O que diferencia sua solução.

---

## N

**Nome Chiclete**
Ver "Gimmick Name". Nome memorável dado ao mecanismo/método.

**Nova Causa**
O que REALMENTE causa o problema do avatar. Também chamado de MUP (Mecanismo Único do Problema).
- **Exemplos:** "Baixos níveis de GLP1" (emagrecimento), "Ponto Cego de Leitura" (concursos)
- **Ref:** Ver "Sexy Cause", "MUP"

**Nova Oportunidade**
O INVERSO da nova causa - o que precisa ser feito. Se a causa é X, a oportunidade é resolver X.
- **Exemplo:** Se causa é "baixos níveis de GLP", oportunidade é "aumentar níveis de GLP"
- **Ref:** Ver "MUS"

**NUUPPECC**
Framework de 8 atributos de atenção: Novo, Urgente, Único, Perigoso, Pessoal, Específico, Concreto, Controverso.

---

## O

**Origin Story**
A história de ONDE veio o mecanismo. Gera credibilidade + curiosidade simultaneamente.
- **Estrutura:** Expert no contexto → Contexto especial → Descobriu padrão → Resultado que prova
- **Exemplos:** "Receita das atrizes de Hollywood", "Técnicas do FBI", "Depois de analisar 10.000 questões"
- **Ref:** Ver "Authority Hook"

---

## S

**Sexy Cause**
A Nova Causa transformada em NOME INTRIGANTE. Faz o prospect pensar "UAU, isso explica TUDO".
- **Teste:** A pessoa quer CONTAR para alguém? Se sim, é sexy.
- **Exemplos:** "Hungry Brain Syndrome" (para baixos níveis de GLP), "Ponto Cego de Leitura" (para falha de reconhecimento)
- **Ref:** Ver "Nova Causa", "MUP"

**Sinestesia da Rotina**
Técnica de usar detalhes sensoriais da rotina real do avatar para criar identificação.

**Superestrutura**
Conceito/produto já conhecido pelo público que dá credibilidade. Ex: Monjaro, Ozempic, Harvard.
- **Uso:** A superestrutura é referenciada no Authority Hook.
- **Ref:** Ver "Authority Hook"

**Swipe File**
Coleção de criativos de referência organizados por nicho para consulta e modelagem.

---

## T

**3Ms**
Framework de Big Ideas: Mistério (gimmick name), Mecanismo (por que funciona), Mercado (demanda validada).

---

## U

**UGC (User Generated Content)**
Conteúdo com estilo caseiro/amador, feito por "usuário comum". Formato que gera autenticidade.

---

## 4 Fortalecedores

Framework de amplificadores de hook:
- **Inesperado** - Quebra padrão mental
- **Concreto** - Detalhe visual/sensorial
- **Crível** - Prova ou autoridade externa
- **Escasso** - Urgência com janela real

---

*Extraído de: Metodologia Vitor Mound (Seção 10) | v1.0 | 2026-01-26*
