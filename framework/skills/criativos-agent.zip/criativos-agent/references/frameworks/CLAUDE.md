# Frameworks - Índice

> **Checklists, templates e processos para criação e revisão de criativos.**

---

## Frameworks Disponíveis

### Metodologia Vitor Mound (NOVO)

| Arquivo | Conteúdo | Linhas |
|---------|----------|--------|
| `frases-de-poder.md` | 6 categorias de frases que amplificam impacto | ~100 |
| `especificidade-prova.md` | Framework de 7 perguntas para especificidade | ~80 |
| `congruencia-formato.md` | Alinhamento de elementos visuais e copy | ~100 |
| `revisao-checklists.md` | 4 checklists: Hook, Body, Congruência, Documento | ~60 |
| `erros-comuns.md` | 7 erros técnicos recorrentes e soluções | ~100 |

### Frameworks Existentes

| Arquivo | Conteúdo |
|---------|----------|
| `principios-2026.md` | Princípios atualizados para 2026 |
| `prsa-dtc.md` | Framework PRSA para Direct-to-Consumer |

---

## Quando Carregar

| Situação | Framework Recomendado |
|----------|----------------------|
| Amplificar impacto do hook | `frases-de-poder.md` |
| Aumentar credibilidade | `especificidade-prova.md` |
| Validar avatar/cenário/edição | `congruencia-formato.md` |
| Revisão final pré-entrega | `revisao-checklists.md` |
| Diagnóstico de criativo fraco | `erros-comuns.md` |
| Briefing estratégico | `prsa-dtc.md` |

---

## Ordem de Leitura Sugerida

Para dominar a metodologia completa:

1. **erros-comuns.md** - Entender o que evitar
2. **especificidade-prova.md** - Base de credibilidade
3. **frases-de-poder.md** - Amplificadores de impacto
4. **congruencia-formato.md** - Alinhamento de elementos
5. **revisao-checklists.md** - Validação final

---

## Relação com Core

Os frameworks complementam o conhecimento CORE:

```
CORE (psicologia + metodologia)
    ↓
FRAMEWORKS (aplicação prática)
    ↓
ESPECÍFICO (ângulos + swipes por nicho)
```

---

*Atualizado: 2026-01-26 | v2.0 (Upgrade Metodologia Vitor Mound)*
