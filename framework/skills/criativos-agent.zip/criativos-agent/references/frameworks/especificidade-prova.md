# Especificidade como Prova

> **Especificidade funciona como um tipo de prova implícita. Afirmações vagas parecem inventadas. Afirmações específicas parecem medidas, documentadas, reais.**

## O Princípio Fundamental

**Mecanismo psicológico:** O cérebro assume que ninguém inventaria detalhes tão específicos. Portanto, deve ser verdade.

---

## O Framework de 7 Perguntas

Para cada afirmação no anúncio, passe pelo checklist:

| Pergunta | Exemplo Vago | Exemplo Específico |
|----------|--------------|-------------------|
| **Quanto?** | "Emagreci muito" | "Perdi 12,4kg" |
| **Em quanto tempo?** | "Em algumas semanas" | "Em 47 dias" |
| **Quem disse?** | "Estudos comprovam" | "Harvard publicou em 2023" |
| **Quando?** | "Recentemente" | "No dia 15 de março" |
| **Onde?** | "Uma universidade" | "MIT, em Boston" |
| **Como?** | "Tomando o chá" | "200ml às 7h da manhã, em jejum" |
| **Qual resultado?** | "Vi diferença" | "No 11º dia, minha calça estava folgada" |

---

## Aplicação por Elemento do Anúncio

### No Hook
❌ Vago: "Perdi peso com isso"
✅ Específico: "Perdi 8kg em 3 semanas com o truque do gengibre"

### Na História
❌ Vago: "Eu estava acima do peso há muito tempo"
✅ Específico: "Há 4 anos eu pesava 87kg e não conseguia subir um lance de escadas"

### No Mecanismo
❌ Vago: "Acelera o metabolismo"
✅ Específico: "Aumenta a taxa metabólica em 23% nas primeiras 4 horas"

### Na Prova
❌ Vago: "Milhares de pessoas já usaram"
✅ Específico: "147.832 pessoas usaram nos últimos 6 meses"

### No Resultado
❌ Vago: "Você vai emagrecer"
✅ Específico: "Você pode perder até 5kg nos primeiros 14 dias"

---

## Especificidade no Visual

A especificidade não é só textual. Elementos visuais também precisam ser específicos:

- Mostrar o número na balança
- Mostrar a calça folgada (não apenas "mencionar")
- Mostrar o antes/depois com datas
- Mostrar o produto sendo usado (não apenas na embalagem)

---

## O Limite da Especificidade

Especificidade aumenta credibilidade, mas excesso vira prolixidade.

### O Equilíbrio

**Seja específico nos pontos de maior ceticismo:**
- Resultados
- Provas
- Origem/autoridade

**Seja conciso nos pontos de menor resistência:**
- Instruções básicas
- Transições
- Contexto secundário

Não transforme cada frase em um parágrafo cheio de detalhes. **Escolha estrategicamente** onde investir especificidade.

---

## Checklist de Especificidade

```
□ Números são específicos (não redondos)?
□ Tempo é específico (dias, não "semanas")?
□ Fontes são nomeadas (não "estudos mostram")?
□ Resultados são concretos e mensuráveis?
□ Histórias têm detalhes sensoriais?
□ Visual mostra (não só fala)?
```

---

*Extraído de: Metodologia Vitor Mound (Seção 5) | v1.0 | 2026-01-26*
