# Sinestesia Anotada

> **FUNDAMENTO UNIVERSAL:** Sempre aplicar, independente de nicho/oferta.
> Fórmula: MOMENTO + SENSAÇÃO + AÇÃO

---

## O que é Sinestesia em Copy

Fazer o leitor VIVER a experiência, não apenas entender racionalmente.
Usar múltiplos sentidos para criar imagem mental vívida.

---

## A Fórmula Universal

```
[MOMENTO ESPECÍFICO] + [SENSAÇÃO FÍSICA] + [AÇÃO CONCRETA]
```

### Componentes

| Componente | O que é | Exemplos |
|------------|---------|----------|
| **MOMENTO** | Quando/onde acontece | "3:00 AM", "na frente do espelho", "na hora da prova" |
| **SENSAÇÃO** | O que o corpo sente | "aquele aperto no peito", "mãos suando", "barriga mais lisa" |
| **AÇÃO** | O que a pessoa faz | "tira a camiseta", "olha pro celular", "fecha a calça" |

---

## Os 6 Sentidos da Copy

### 1. VISUAL (o que VÊ)
```
❌ "Você vai emagrecer"
✅ "Barriga mais lisa. Toca a pele e consegue sentir as costelas."
```

### 2. AUDITIVO (o que OUVE)
```
❌ "Família vai apoiar"
✅ "'E aí, passou?' — todo mundo pergunta como se fosse fácil"
```

### 3. TÁTIL (o que TOCA/SENTE na pele)
```
❌ "Vai se sentir melhor"
✅ "Coloca o jeans que não cabia. Fecha."
```

### 4. TEMPORAL (momento específico)
```
❌ "Acordar cansada"
✅ "3:00 AM. Você acorda sem aquela fome de morte."
```

### 5. PROPRIOCEPTIVO (corpo no espaço)
```
❌ "Mais energia"
✅ "Subir as escadas sem parar no meio pra respirar"
```

### 6. SOCIAL (interação com outros)
```
❌ "Reconhecimento"
✅ "Seu nome na lista. LÁ. Liga pra mãe gritando. A mãe chora."
```

---

## 10 Exemplos Universais

### 1. Resultado Físico (Emagrecimento/Saúde)
```
ANTES: "Você vai perder peso"
DEPOIS: "Tira a camiseta. Barriga mais lisa. Toca a pele e consegue sentir as costelas de novo."
```

### 2. Resultado Emocional (Relacionamento)
```
ANTES: "Vai se sentir amada"
DEPOIS: "Ele olha pra você do jeito que olhava no começo. Aquele olhar."
```

### 3. Resultado Financeiro (Renda Extra)
```
ANTES: "Vai ganhar mais dinheiro"
DEPOIS: "Abre o app do banco. Vê o saldo. Não dá aquele aperto."
```

### 4. Resultado de Aprovação (Concursos)
```
ANTES: "Vai passar no concurso"
DEPOIS: "Seu nome na lista. LÁ. Liga pra mãe gritando. A mãe chora."
```

### 5. Resultado de Energia (Saúde Geral)
```
ANTES: "Vai ter mais energia"
DEPOIS: "Acordar antes do despertador. Sem aquela moleza de sempre."
```

### 6. Resultado de Confiança (Performance)
```
ANTES: "Vai ser mais confiante"
DEPOIS: "Entrar na reunião e falar. Sem a voz tremer."
```

### 7. Momento de Dor (Identificação)
```
ANTES: "Você está frustrada com dieta"
DEPOIS: "Se olhar no espelho do banheiro. Não se reconhecer."
```

### 8. Momento de Falha (MUP)
```
ANTES: "Você errou questões"
DEPOIS: "Olhar pro gabarito. Pensar 'MAS EU SABIA ISSO'."
```

### 9. Momento de Descoberta (MUS)
```
ANTES: "Achei um método"
DEPOIS: "Na primeira vez que usei, parecia trapaça."
```

### 10. Momento de Transformação (Future Pacing)
```
ANTES: "Sua vida vai mudar"
DEPOIS: "Vestir aquela roupa que tá no fundo do armário há meses."
```

---

## Como Adaptar para Qualquer Nicho

### Passo 1: Identificar o RESULTADO
Qual é a transformação prometida?

### Passo 2: Encontrar o MOMENTO
Em que situação específica o avatar vai SENTIR essa transformação?

### Passo 3: Descrever a SENSAÇÃO
O que o CORPO dele vai sentir nesse momento?

### Passo 4: Adicionar a AÇÃO
O que ele vai FAZER nesse momento?

---

## Template Universal

```
[Horário/Local]. [Ação que revela resultado]. [Sensação física]. [Contraste implícito com antes].
```

**Exemplo preenchido:**
```
3:00 AM. Você acorda sem aquela fome de morte.
Tira a camiseta. Barriga mais lisa.
Toca a pele e consegue sentir as costelas.
```

---

## Checklist de Sinestesia

Antes de entregar, verificar:

- [ ] Tem pelo menos 3 sentidos descritos?
- [ ] O MOMENTO é específico (não genérico)?
- [ ] A SENSAÇÃO é física (não abstrata)?
- [ ] A AÇÃO é concreta (não "vai se sentir melhor")?
- [ ] O leitor consegue SE VER na cena?

---

## O que NÃO fazer

### Erro 1: Abstração
```
❌ "Você vai se sentir mais leve"
✅ "A calça que não fechava mais. Fecha."
```

### Erro 2: Generalização
```
❌ "Resultados incríveis"
✅ "Em duas semanas a calça já tava folgada"
```

### Erro 3: Foco no Produto
```
❌ "O suplemento contém 5 ingredientes"
✅ "Tomei antes de dormir. Acordei diferente."
```

---

*Criado: 2026-01-27 | Versão: 1.0*
*Fórmula universal — aplicar em qualquer nicho*
