# Checklist de Humanidade

> **OBJETIVO:** Validar que copy é HUMANA, não apenas tecnicamente correta.
> 6 checkpoints que rodam APÓS a técnica, validando autenticidade.

---

## Quando Usar

Rodar APÓS produzir o criativo, ANTES de entregar:

```
1. Produzir copy (técnica)
2. Rodar Checklist de Humanidade (validação)
3. Se FALHAR → reescrever trecho
4. Se PASSAR → entregar
```

---

## CHECKPOINT 0: Descoberta de Contexto

**Quando:** ANTES de produzir

### Perguntas

- [ ] Qual é o nicho da oferta?
- [ ] Li 2-3 swipes do nicho?
- [ ] Extrai TOM dominante dos swipes?
- [ ] Extrai GÍRIAS do nicho?
- [ ] Extrai RITMO típico?

### Fail Trigger
> Se NÃO li swipes → **PARAR**. Ler swipes antes de continuar.

### Exemplo de Reprovação
```
❌ Começou a escrever sem ler swipes
❌ Usou tom de outro nicho
❌ Inventou gírias
```

### Correção
```
1. Listar: ls ~/.claude/skills/criativos-agent/references/swipe-files/{nicho}/
2. Ler 2-3 swipes
3. Documentar tom/gírias/ritmo
4. Só então produzir
```

---

## CHECKPOINT 1: Tensão Dramática

**Quando:** APÓS construir HOOK

### Perguntas

- [ ] Existe paradoxo ou contradição no hook?
- [ ] O avatar SENTE conflito (não só reconhece problema)?
- [ ] A tensão ESCALDA ao longo da copy?
- [ ] Existe algo em JOGO (risco, revelação, injustiça)?

### Fail Trigger
> Se <2 respostas SIM → **REESCREVER** hook para adicionar tensão.

### Exemplo de Reprovação
```
❌ "Se você já tentou emagrecer..."
   (reconhece problema, mas não cria conflito)
```

### Correção
```
✅ "Quem estuda menos sempre passa.
   Parece injusto, né?"
   (paradoxo + questiona justiça)
```

---

## CHECKPOINT 2: Especificidade Visceral

**Quando:** APÓS construir BODY

### Perguntas

Quantos SENTIDOS estão descritos?

- [ ] VISUAL: O que a pessoa VÊ?
- [ ] AUDITIVO: O que OUVE?
- [ ] TÁTIL: O que TOCA ou SENTE na pele?
- [ ] OLFATIVO: Qual é o CHEIRO?
- [ ] GUSTATIVO: Existe SABOR?
- [ ] PROPRIOCEPTIVO: Como o CORPO está no espaço?

### Fail Trigger
> Se <4 sentidos → **REESCREVER** com mais sensorialidade.

### Exemplo de Reprovação
```
❌ "Você vai se sentir melhor"
   (abstrato, nenhum sentido)
```

### Correção
```
✅ "3:00 AM. Você acorda sem aquela fome de morte.
   Tira a camiseta. Barriga mais lisa.
   Toca a pele e consegue sentir as costelas."
   (temporal + visual + tátil)
```

---

## CHECKPOINT 3: Ritmo/Respiração

**Quando:** APÓS copy completa

### Processo

1. **LER EM VOZ ALTA** (literalmente)
2. Marcar com ✓ cada lugar onde você PAUSA naturalmente
3. Responder:

- [ ] Existem 3+ pausas naturais no hook?
- [ ] Depois de seção tensa, existe DESCANSO (frase longa + simples)?
- [ ] Existe alguma frase que ENGASGA quando dita?

### Fail Trigger
> Se >1 frase "engasgada" OU <3 pausas no hook → **REVISAR ritmo**.

### Exemplo de Reprovação
```
❌ "Este método foi desenvolvido para auxiliar pessoas
   que desejam melhorar seu desempenho em provas
   através de técnicas cientificamente comprovadas."
   (uma frase longa sem pausas)
```

### Correção
```
✅ "Você estuda. Estuda. Estuda.
   E na hora da prova?
   Erra o que sabia."
   (pausas naturais, variação)
```

---

## CHECKPOINT 4: Consistência com Contexto

**Quando:** APÓS copy completa

### Perguntas

- [ ] O TOM é CONSISTENTE com os swipes do nicho?
- [ ] As GÍRIAS são do nicho (não inventadas)?
- [ ] O RITMO segue o padrão do nicho?
- [ ] O ESTILO foi MODELADO dos swipes, não hardcoded?

### Fail Trigger
> Se qualquer resposta NÃO → **REVISAR** para alinhar com swipes.

### Exemplo de Reprovação
```
❌ Usou "tomando fumo" em criativo de diabetes
   (gíria de concursos, não de saúde)

❌ Usou tom de raiva em criativo de maternidade
   (tom não combina com nicho)
```

### Correção
```
1. Reler swipes do nicho
2. Identificar tom/gírias corretas
3. Substituir elementos inconsistentes
```

---

## CHECKPOINT 5: Releitura Humanizada Final

**Quando:** ÚLTIMO passo, APÓS análise técnica

### Processo

1. **REMOVER** todas as tags [HOOK], [MUP], [CTA]
2. **LER** a copy inteira como consumidor
3. Responder:

- [ ] Pararia de rolar o feed?
- [ ] Acreditaria nisto?
- [ ] Compartilharia com um amigo?
- [ ] Existe alguma parte que EU PULARIA se estivesse assistindo?
- [ ] Se eu SOUBESSE que foi IA, ainda confiaria?

### Fail Trigger
> Se >1 resposta NÃO → **Identificar** o trecho e **REESCREVER**.

### Exemplo de Reprovação
```
❌ "Os 5 componentes trabalham juntos para te preparar."
   (parece slide de vendas, pularia)
```

### Correção
```
✅ "Na primeira vez que usei, parecia trapaça.
   Ela me apontava exatamente onde tava a pegadinha."
   (experiência pessoal, não pularia)
```

---

## Resumo Executivo

| # | Checkpoint | Quando | Fail = |
|---|------------|--------|--------|
| 0 | Descoberta de Contexto | ANTES | Parar e ler swipes |
| 1 | Tensão Dramática | Pós-hook | Reescrever hook |
| 2 | Especificidade Visceral | Pós-body | Adicionar sentidos |
| 3 | Ritmo/Respiração | Pós-copy | Revisar variação |
| 4 | Consistência | Pós-copy | Alinhar com nicho |
| 5 | Releitura Final | Último | Reescrever trechos |

---

## Checklist Rápido (Para Colar)

```
ANTES DE PRODUZIR:
□ [0] Li 2-3 swipes do nicho?

APÓS PRODUZIR:
□ [1] Existe tensão/conflito no hook?
□ [2] ≥4 sentidos descritos?
□ [3] Ritmo varia? Pausas naturais?
□ [4] Estilo consistente com swipes?
□ [5] Passaria no teste "se eu soubesse que foi IA"?
```

---

*Criado: 2026-01-27 | Versão: 1.0*
*Checkpoints validam técnica, não hardcodam estilo*
