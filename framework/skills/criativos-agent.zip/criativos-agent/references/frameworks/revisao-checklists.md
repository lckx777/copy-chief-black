# Frameworks de Revisão

> **Checklists estruturados para validar cada elemento do criativo antes de finalizar.**

## Checklist de Hook

Antes de finalizar, verifique:

```
□ O hook qualifica o público-alvo?
□ O hook transmite uma emoção específica?
□ O hook gera curiosidade?
□ A informação mais importante vem primeiro?
□ Existe nome chiclete (se aplicável)?
□ Existe frase de poder (se aplicável)?
□ O hook faria alguém parar de rolar o feed?
□ Se o lead passou "de boa", reescrever
```

---

## Checklist de Body

```
□ Existem disparos de dopamina após seções técnicas?
□ O texto é conciso (não prolixo)?
□ As afirmações são específicas (não vagas)?
□ Os elementos essenciais estão presentes?
□ O texto flui naturalmente quando lido em voz alta?
□ Existe prova adequada?
□ Tem MUP e MUS claros?
□ Tem future pacing sensorial?
```

---

## Checklist de Congruência

```
□ Avatar é adequado para o público-alvo?
□ Cenário é congruente com a mensagem?
□ Tom de comunicação combina com o avatar?
□ Elementos visuais provam o que o texto diz?
□ Edição é congruente com o tipo de comunicação?
```

---

## Checklist de Documento

Para o editor/produção:

```
□ Link do avatar está incluído?
□ Referências de edição estão incluídas?
□ Comentários explicativos estão claros?
□ Músicas/sons estão indicados?
□ Tom de voz desejado está especificado?
□ Um editor conseguiria recriar sua visão?
```

---

## Checklist Geral de Qualidade

### ANTES DE ESCREVER
```
□ Defini os 3Ms (Mistério, Mecanismo, Mercado)?
□ Defini REAÇÃO (emoção) + AÇÃO (clique)?
□ Consultei 3+ swipes de referência?
```

### DEPOIS DE ESCREVER
```
□ Deixei incubar antes de editar?
□ Ritmo variado (curto + médio + longo)?
□ Nível de leitura 6ª-8ª série?
□ Lido em voz alta soa como conversa?
```

---

## Teste Final: Você Pararia?

Antes de enviar, pergunte:
- "Eu pararia para ver isso no meu feed?"
- "Isso está chato?"
- "Existe alguma parte que eu pularia se estivesse assistindo?"

Se a resposta for sim para qualquer negativa, **reescreva** — mesmo que signifique "quebrar" a estrutura.

---

*Extraído de: Metodologia Vitor Mound (Seção 9) | v1.0 | 2026-01-26*
