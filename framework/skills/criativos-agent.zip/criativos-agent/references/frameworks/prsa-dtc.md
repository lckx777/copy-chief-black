# Framework PRSA para Criativos DTC

## Contexto

**DTC (Direct to Consumer)** = Estilo TikTok Shop, copys curtas e diretas.

**Quando usar:**
- Low-ticket (até R$97)
- Leads frias
- Plataformas de scroll rápido (TikTok, Reels, Shorts)
- Mercado saturado com dopamina baixa

---

## O Framework PRSA

```
P → PROBLEMA (1-2 frases)
R → ROTA (caminho/descoberta)
S → SOLUÇÃO (mecanismo/produto)
A → AÇÃO (CTA direto)
```

---

## Detalhamento

### P - PROBLEMA

**Função:** Identificar dor específica em 1-2 frases impactantes.

**Regras:**
- Ser ESPECÍFICO (não genérico)
- Usar linguagem do avatar
- Gerar identificação imediata

**Exemplos:**
```
❌ "Você está cansado de não conseguir emagrecer?"
✅ "Você sente que sua barriga não diminui mesmo fazendo dieta?"

❌ "Quer passar em concurso?"
✅ "Leu a lei 50 vezes e não decorou?"
```

---

### R - ROTA

**Função:** Mostrar o caminho/descoberta que levou à solução.

**Elementos da Rota:**
1. **Epifania** - Momento de virada
2. **Descoberta** - O que você encontrou
3. **Underground** - Fonte inesperada (opcional)

**Exemplos:**
```
"Até que descobri que o problema não era minha memória..."
"Foi quando encontrei uma comunidade secreta de aprovados..."
"Pesquisadores de Harvard revelaram que..."
```

---

### S - SOLUÇÃO

**Função:** Apresentar o mecanismo/produto de forma intrigante.

**Regras:**
- Usar GIMMICK NAME se possível
- Ser intrigante, não explicativo
- Gerar curiosidade sobre o "como"

**Exemplos:**
```
"...que existe um método chamado Âncora que fecha os 3 buracos da memória"
"...uma fruta asiática que ativa o hormônio da queima noturna"
"...comandos específicos que fazem o ChatGPT estudar por você"
```

---

### A - AÇÃO

**Função:** CTA direto e urgente.

**Tipos de CTA:**
1. **Suave:** "Deixei disponível no botão aqui embaixo"
2. **Direto:** "Clica no link agora"
3. **Urgência:** "Corre que pode sair do ar"
4. **Escassez:** "Últimas vagas"

**Exemplos:**
```
"Pra acessar é só tocar no botão. Acho que ainda está disponível."
"Clica no link antes que saia do ar."
"Deixei o acesso liberado por 24h no botão abaixo."
```

---

## Template Completo

```markdown
## CRIATIVO DTC - PRSA

**Nicho:** [categoria]
**Formato:** [UGC/POV/Talking Head]
**Duração:** 30-60s

---

[P - PROBLEMA]
> "[Dor específica em 1-2 frases]"

[R - ROTA]
> "[Momento de descoberta / epifania]"

[S - SOLUÇÃO]
> "[Mecanismo/produto de forma intrigante]"

[A - AÇÃO]
> "[CTA direto]"
```

---

## Exemplo Aplicado: Gabaritando Lei Seca

```markdown
[P - PROBLEMA]
> "Você leu a lei 50 vezes e ainda não decorou?"

[R - ROTA]
> "Eu também passei por isso até descobrir que o problema não era minha memória. Era o método."

[S - SOLUÇÃO]
> "Pesquisadores de Harvard identificaram que a lei escapa do cérebro por 3 buracos diferentes. E existe um método que fecha os 3."

[A - AÇÃO]
> "Toca no botão pra conhecer o Método Âncora. Acho que ainda tá disponível."
```

---

## Variações de Estrutura

### PRSA Curto (15-30s)
```
P: "Leu a lei 50x e não decorou?"
R: "O problema não é você."
S: "É que seu método só tampa 1 dos 3 buracos."
A: "Link na bio."
```

### PRSA Médio (30-60s)
```
P: [2 frases de dor]
R: [1-2 frases de descoberta]
S: [2-3 frases de mecanismo]
A: [CTA com urgência suave]
```

### PRSA Expandido (60-90s)
```
P: [Dor + Amplificação]
R: [História de descoberta completa]
S: [Mecanismo + Benefício principal]
A: [CTA duplo: suave + direto]
```

---

## Checklist de Validação

- [ ] Problema é ESPECÍFICO (não genérico)?
- [ ] Rota tem elemento de DESCOBERTA?
- [ ] Solução gera CURIOSIDADE (não explica tudo)?
- [ ] Ação é CLARA e DIRETA?
- [ ] Duração adequada ao formato?
- [ ] Linguagem do AVATAR?
