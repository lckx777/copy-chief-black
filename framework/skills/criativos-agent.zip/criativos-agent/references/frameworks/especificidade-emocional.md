# Especificidade Emocional

> **FUNDAMENTO UNIVERSAL:** Sempre aplicar, independente de nicho/oferta.
> Uma memória específica > um número estatístico.

---

## O Problema

A IA tende a gerar especificidade FACTUAL (números, datas, percentuais) mas falha em especificidade EMOCIONAL (memórias, perdas, consequências).

### Exemplo do Problema

```
❌ FACTUAL (mecânico):
"89% dos candidatos reprovam"
"Estudei 4 anos"
"Gastei R$15.000"

✅ EMOCIONAL (visceral):
"Uma palavra. Uma única palavra me custou a vaga na Polícia Federal"
"Em 6 anos pagando cursinho, ninguém nunca me ensinou isso"
"Depois de ser reprovado pela quarta vez, eu finalmente descobri..."
```

---

## Framework de Transformação

### 1. NÚMERO → CONSEQUÊNCIA PESSOAL

| De | Para |
|----|------|
| "89% reprovam" | "9 de cada 10 pessoas que estão lendo isso vão reprovar" |
| "Gastei R$15.000" | "O dinheiro que eu ia usar pra dar entrada no carro" |
| "4 anos" | "Enquanto todos os meus amigos se formaram, eu ainda estava..." |

### 2. TEMPO → OPORTUNIDADE PERDIDA

| De | Para |
|----|------|
| "Demorei 2 anos" | "2 anos que eu nunca vou recuperar" |
| "10 horas por dia" | "Enquanto todo mundo vivia, eu estava trancado estudando" |
| "15 anos" | "Uma armadilha que a CEBRASPE repete há mais de 15 anos" |

### 3. ESTATÍSTICA → MEMÓRIA ESPECÍFICA

| De | Para |
|----|------|
| "34% das questões" | "Pelo menos uma de cada três alternativas" |
| "Maioria erra" | "Eu tinha certeza que estava certo. Era errado." |
| "Taxa de aprovação baixa" | "De 50 mil inscritos, 200 passaram. Eu não era um deles." |

---

## Teste: A Consequência é Identificável?

### Pergunta-Chave
> "O leitor consegue VISUALIZAR exatamente qual foi a perda?"

### Exemplos

**VAGO (não passa no teste):**
- "Perdi minha oportunidade"
- "Fiz uma prova ruim"
- "Não consegui o resultado"

**ESPECÍFICO (passa no teste):**
- "Me custou a vaga na Polícia Federal"
- "Errei a questão que eu SABIA a resposta"
- "Reprovado pela quarta vez"

---

## Os 5 Sentidos da Especificidade

Para máxima especificidade emocional, descrever SENSAÇÕES:

### 1. VISUAL
```
❌ "Fiquei triste"
✅ "Olhei pro gabarito e meu nome não estava lá"
```

### 2. AUDITIVO
```
❌ "Minha família não apoiava"
✅ "'Vai procurar emprego de verdade' - toda semana"
```

### 3. TÁTIL
```
❌ "Me senti pesado"
✅ "A calça que não fechava mais"
```

### 4. TEMPORAL
```
❌ "Demorou muito"
✅ "3:00 da manhã, ainda estudando, acordando 6h pro trabalho"
```

### 5. SOCIAL
```
❌ "Ninguém entendia"
✅ "'E aí, passou?' - todo mundo pergunta como se fosse fácil"
```

---

## Aplicação por Camada

### Camada 1: Identificação
Transformar o momento de identificação em memória dolorosa:

```
❌ "Você já errou questão por falta de atenção?"
✅ "Sabe aquela sensação de olhar pro gabarito e pensar 'MAS EU SABIA ISSO'?"
```

### Camada 2: Problema (MUP)
Transformar estatísticas em impacto pessoal:

```
❌ "34% das questões têm absolutizantes"
✅ "Pelo menos uma de cada três alternativas é armadilha"
```

### Camada 3: Solução (MUS)
Transformar funcionalidade em experiência:

```
❌ "A plataforma identifica padrões"
✅ "Na primeira vez que usei, parecia trapaça"
```

### Camada 4: Future Pacing
Transformar benefício em momento vivido:

```
❌ "Você vai passar"
✅ "Seu nome na lista. LÁ. Liga pra mãe gritando. A mãe chora."
```

---

## Checklist de Especificidade Emocional

Antes de entregar, verificar:

- [ ] Números foram transformados em consequências pessoais?
- [ ] Existe pelo menos UMA memória dolorosa específica?
- [ ] O leitor consegue VISUALIZAR a perda/ganho?
- [ ] Usa SENSAÇÕES (visual, auditivo, tátil)?
- [ ] Não é genérico ("perdi minha oportunidade")?

---

## O que NÃO fazer

### Erro 1: Especificidade Forçada
```
❌ "Exatamente às 14:37 do dia 15 de março de 2024"
```
Números específicos SEM contexto emocional não funcionam.

### Erro 2: Especificidade Genérica
```
❌ "4 anos estudando" (número sem consequência)
✅ "4 anos enquanto meus amigos casavam, viajavam, viviam"
```

### Erro 3: Especificidade Corporativa
```
❌ "Implementação de metodologia validada cientificamente"
✅ "Uma técnica que funciona em 10 segundos"
```

---

*Criado: 2026-01-27 | Versão: 1.0*
*Fundamento universal - aplicar em qualquer nicho*
