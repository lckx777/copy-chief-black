# Frases de Poder

> **Construções linguísticas que amplificam o impacto de qualquer afirmação subsequente.**

## Definição

Frases de poder são "multiplicadores de força" que transformam hooks medianos em hooks poderosos. Funcionam criando uma "preparação psicológica" antes da informação principal.

## Mecanismo de Funcionamento

Isso ativa no cérebro:
- Estado de alerta aumentado
- Curiosidade antecipatória
- Sensação de acesso privilegiado
- Percepção de autenticidade/vulnerabilidade

---

## Catálogo Completo

### Categoria: Informação Oculta
```
"Vou te contar o que nunca te falaram sobre..."
"O que ninguém tem coragem de dizer é que..."
"Existe algo que os médicos não contam..."
"O segredo que a indústria esconde é..."
"O que você não sabe sobre..."
```

### Categoria: Risco Pessoal
```
"Posso ser cancelado por falar isso, mas..."
"Vão me odiar por revelar isso, mas..."
"Isso pode me dar problemas, mas..."
"Nunca falei isso publicamente, mas..."
"Vou arriscar minha reputação dizendo isso..."
```

### Categoria: Contradição/Quebra de Expectativa
```
"Isso vai ser contraditório, mas..."
"Parece loucura, mas..."
"Eu sei que vai soar estranho, mas..."
"Contra tudo que você já ouviu..."
"O oposto do que te ensinaram..."
```

### Categoria: Vulnerabilidade/Honestidade
```
"Vou ser honesta com você..."
"Preciso confessar uma coisa..."
"A verdade que eu escondi por anos..."
"Tenho vergonha de admitir, mas..."
"Não é fácil dizer isso, mas..."
```

### Categoria: Urgência/Escassez
```
"Essa é a última vez que vou falar sobre..."
"Antes que removam esse vídeo..."
"Enquanto ainda posso compartilhar..."
"Não sei quanto tempo isso vai durar, mas..."
```

### Categoria: Exclusividade
```
"O que vou mostrar agora, poucos sabem..."
"Isso aqui não está em nenhum lugar..."
"Pela primeira vez estou revelando..."
"Só quem [condição] vai entender..."
```

---

## Como Aplicar

### Método de Aplicação
1. Escreva seu hook original
2. Identifique qual categoria de frase de poder se encaixa
3. Adicione a frase de poder ANTES do hook
4. Ajuste a fluidez da transição

### Exemplo de Transformação

**Hook original:**
> "Água com limão não emagrece."

**Com frase de poder (Risco Pessoal):**
> "Posso ser cancelada por falar isso, mas água com limão não emagrece."

**Com frase de poder (Informação Oculta):**
> "O que ninguém tem coragem de te dizer: água com limão não emagrece."

**Com frase de poder (Honestidade):**
> "Vou ser honesta com você: água com limão não emagrece."

---

## Erro Comum na Modelagem

Muitos copywriters veem um anúncio escalando, modelam, e **removem a frase de poder** achando que "não tem nada a ver com o conteúdo" ou que é "encheção de linguiça".

**O que acontece:** O hook perde a força. A versão modelada não performa. O copywriter não entende por quê.

**Regra:** Ao modelar, identifique as frases de poder e mantenha-as (ou substitua por equivalentes). Elas não são decoração — são parte do mecanismo persuasivo.

---

## Combinações por Nicho

| Nicho | Categorias que funcionam melhor |
|-------|--------------------------------|
| Saúde | Informação Oculta + Risco Pessoal |
| Concursos | Vulnerabilidade + Exclusividade |
| Riqueza | Contradição + Risco Pessoal |
| Relacionamento | Vulnerabilidade + Honestidade |

---

*Extraído de: Metodologia Vitor Mound (Seção 2) | v1.0 | 2026-01-26*
