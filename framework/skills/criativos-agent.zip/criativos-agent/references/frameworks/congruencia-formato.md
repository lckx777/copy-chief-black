# Congruência e Formato

> **Congruência é o alinhamento total entre todos os elementos do anúncio. Quando todos os elementos contam a mesma história, o anúncio gera credibilidade. Quando há conflito entre elementos, gera desconfiança (mesmo inconsciente).**

## Definição de Congruência

Elementos que devem estar alinhados:
- **Texto (copy escrita)**
- **Avatar (quem aparece falando)**
- **Cenário (onde a pessoa está)**
- **Tom de voz (como fala)**
- **Edição (ritmo, cortes, música)**
- **Elementos visuais (roupas, objetos, ambiente)**

---

## Erros de Congruência Comuns

### Erro 1: Conflito Avatar x Comunicação
❌ **Problema:** Médico/especialista usando gírias de rua, comunicação informal demais
❌ **Problema inverso:** Pessoa comum falando com termos técnicos demais
✅ **Solução:** Alinhar o nível de linguagem com quem está falando

### Erro 2: Conflito Cenário x Mensagem
❌ **Problema:** Copy fala "parei de ir pra academia", avatar está numa academia
❌ **Problema:** Copy fala "faço isso em casa toda manhã", avatar em estúdio profissional
✅ **Solução:** O cenário deve provar visualmente o que o texto diz

### Erro 3: Conflito Avatar x Público-Alvo
❌ **Problema:** Copy para mães, avatar é mulher jovem sem elementos de maternidade
❌ **Problema:** Copy para idosos, avatar é pessoa de 30 anos
✅ **Solução:** Avatar deve ser identificável pelo público-alvo

### Erro 4: Conflito Visual x Promessa
❌ **Problema:** Copy promete emagrecimento, avatar está visivelmente acima do peso
❌ **Problema:** Copy fala de resultado, nenhum elemento visual mostra o resultado
✅ **Solução:** O visual deve ser prova da promessa

---

## Prova Implícita pelo Formato

O cenário e a ação visual funcionam como PROVA do que está sendo dito, sem precisar verbalizar.

| Se o texto diz... | O visual deve mostrar... |
|-------------------|-------------------------|
| "Faço essa receita toda manhã" | Avatar na cozinha fazendo a receita |
| "Sou mãe e não tenho tempo" | Avatar com bebê/criança visível |
| "Parei de ir pra academia" | Avatar em casa, ambiente doméstico |
| "Emagreci 15kg" | Avatar com corpo compatível + elemento de antes |
| "É simples de fazer" | Demonstração visual da simplicidade |

---

## Case: Congruência para Público de Mães

**Público:** Mães que querem emagrecer

**Checklist de congruência:**
- ✓ **Avatar:** Mulher com corpo "real" (não fitness, não obesa)
- ✓ **Elemento visual de maternidade:** Bebê no colo, brinquedos ao fundo, cadeirinha
- ✓ **Cenário:** Casa, cozinha, sala — ambiente doméstico
- ✓ **Comunicação:** Mencionar desafios de mãe (tempo, cansaço, priorizar filhos)
- ✓ **Tom:** Empático, solidário, "de mãe para mãe"

**Resultado:** Identificação instantânea antes mesmo de processar as palavras. A mãe vê e pensa "essa é igual a mim" nos primeiros segundos.

---

## Congruência no Formato de Edição

A edição também precisa ser congruente com a comunicação:

| Tipo de Comunicação | Edição Congruente |
|---------------------|-------------------|
| Conteúdo orgânico/caseiro | Edição simples, poucos cortes, sem efeitos |
| Expert/autoridade | Edição limpa, profissional, sem exageros |
| Urgência/escassez | Ritmo rápido, cortes frequentes |
| Testemunho emocional | Edição suave, música emotiva, takes longos |
| Entretenimento/humor | Edição dinâmica, memes, efeitos populares |

---

## Matriz de Congruência por Nicho

### Emagrecimento
| Elemento | Congruente | Incongruente |
|----------|------------|--------------|
| Avatar | Mulher 35-55, corpo "normal" | Modelo fitness |
| Cenário | Cozinha, casa | Estúdio, academia |
| Tom | Confessional, empático | Técnico, autoritário |

### Concursos
| Elemento | Congruente | Incongruente |
|----------|------------|--------------|
| Avatar | Pessoa comum, visual de estudante | Expert de terno |
| Cenário | Mesa de estudos, biblioteca | Escritório corporativo |
| Tom | Solidário, jornada | Promessa fácil |

### Renda Extra
| Elemento | Congruente | Incongruente |
|----------|------------|--------------|
| Avatar | Pessoa comum mostrando resultado | Ostentação exagerada |
| Cenário | Casa normal melhorada | Mansão, carro de luxo |
| Tom | Prático, passo a passo | "Fique rico rápido" |

---

## Checklist de Congruência

```
□ Avatar é adequado para o público-alvo?
□ Cenário é congruente com a mensagem?
□ Tom de comunicação combina com o avatar?
□ Elementos visuais provam o que o texto diz?
□ Edição é congruente com o tipo de comunicação?
□ Não há conflito entre nenhum elemento?
```

---

*Extraído de: Metodologia Vitor Mound (Seção 6) | v1.0 | 2026-01-26*
