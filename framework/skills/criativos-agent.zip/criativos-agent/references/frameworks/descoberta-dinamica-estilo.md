# Descoberta Dinâmica de Estilo

> **REGRA:** Estilo (tom, emoção, gírias) NÃO é hardcoded.
> Deve ser DESCOBERTO a partir dos swipes do nicho.

---

## Por que Descoberta Dinâmica?

### O Problema
A IA tende a aplicar estilo GENÉRICO ou HARDCODED:
- Usar "raiva" em todos os criativos (funciona em concursos, não em maternidade)
- Usar "deboche" universalmente (funciona em saúde, não em luto)
- Inventar gírias que não existem no nicho

### A Solução
ANTES de produzir, extrair estilo dos SWIPES do nicho.

---

## Workflow de Descoberta

### ETAPA 0: Identificar Nicho

```
1. Qual é o nicho da oferta?
   - concursos, emagrecimento, relacionamento, diabetes, etc.

2. Onde estão os swipes?
   ~/.claude/skills/criativos-agent/references/swipe-files/{nicho}/
```

### ETAPA 1: Listar Swipes Disponíveis

```bash
ls ~/.claude/skills/criativos-agent/references/swipe-files/{nicho}/
```

### ETAPA 2: Ler 2-3 Swipes do Nicho

Escolher swipes que:
- Parecem estar escalando (muitas variações)
- Representam ângulos diferentes
- Têm tom marcante

### ETAPA 3: Extrair Elementos de Estilo

Para cada swipe, identificar:

| Elemento | Perguntas |
|----------|-----------|
| **TOM** | Raiva? Humor? Autoridade? Vulnerabilidade? Urgência? |
| **GÍRIAS** | Quais expressões do nicho aparecem? |
| **RITMO** | Frases curtas? Longas? Mistas? |
| **EMOÇÃO** | Qual emoção dominante? Medo? Esperança? Frustração? |

### ETAPA 4: Consolidar Padrão do Nicho

```markdown
## Estilo Extraído: [NICHO]

**Tom Dominante:** [ex: raiva controlada + conspiração]
**Gírias do Nicho:** [ex: "tomando fumo", "famosinhas", "hack"]
**Ritmo Típico:** [ex: frases curtas + punch + pausa]
**Emoção Dominante:** [ex: frustração → raiva → esperança]
**Ângulos que Escalam:** [ex: conspiração, nova descoberta, erro comum]
```

---

## Mapeamento Nicho → Pasta

| Nicho | Pasta | Swipes |
|-------|-------|--------|
| concursos | `swipe-files/concursos/` | 10+ |
| diabetes | `swipe-files/diabetes/` | 12+ |
| emagrecimento | `swipe-files/emagrecimento/` | 12+ |
| relacionamento | `swipe-files/relacionamento/` | 10+ |
| ed | `swipe-files/ed/` | 14+ |
| alzheimer | `swipe-files/alzheimer/` | 5+ |
| aumento-peniano | `swipe-files/aumento-peniano/` | 6+ |
| lei-da-atracao | `swipe-files/lei-da-atracao/` | 10+ |
| renda-extra | `swipe-files/renda-extra/` | 10+ |
| prostata | `swipe-files/prostata/` | 7+ |
| rejuvenescimento | `swipe-files/rejuvenescimento/` | 8+ |
| saude-mental | `swipe-files/saude-mental/` | 6+ |
| sexualidade | `swipe-files/sexualidade/` | 8+ |
| visao | `swipe-files/visao/` | 6+ |
| ... | ... | 24 nichos total |

---

## Exemplos de Estilo por Nicho

### Concursos
**Tom:** Raiva controlada + conspiração
**Gírias:** "tomando fumo", "famosinhas", "hack", "trapaça"
**Ritmo:** Curto + punch + pausa reflexiva
**Emoção:** Frustração → Raiva → Esperança

### Diabetes
**Tom:** Urgência + nova descoberta científica
**Gírias:** "natural", "caseiro", "sem remédio"
**Ritmo:** Científico mas acessível
**Emoção:** Medo → Alívio → Controle

### Relacionamento
**Tom:** Vulnerabilidade + empoderamento
**Gírias:** "volta pro ex", "tóxico", "self-love"
**Ritmo:** Confessional, pausas dramáticas
**Emoção:** Dor → Aceitação → Transformação

### Emagrecimento
**Tom:** Paradoxo + sem culpa
**Gírias:** "metabolismo", "detox", "sem dieta"
**Ritmo:** Rápido, urgente
**Emoção:** Frustração → Esperança → Urgência

---

## Checklist de Descoberta

Antes de produzir, validar:

- [ ] Identifiquei o nicho da oferta?
- [ ] Li 2-3 swipes do nicho?
- [ ] Extrai TOM dominante?
- [ ] Extrai GÍRIAS do nicho?
- [ ] Extrai RITMO típico?
- [ ] Extrai EMOÇÃO dominante?
- [ ] VOU MODELAR o estilo, não inventar?

---

## Anti-Patterns

### Erro 1: Hardcodar Estilo
```
❌ "Todo criativo precisa ter raiva"
✅ "Criativos de concursos geralmente têm raiva (validar via swipes)"
```

### Erro 2: Ignorar Swipes
```
❌ Escrever sem ler nenhum swipe do nicho
✅ Ler 2-3 swipes ANTES de produzir
```

### Erro 3: Misturar Nichos
```
❌ Usar gírias de concursos em criativo de diabetes
✅ Usar gírias extraídas dos swipes de diabetes
```

### Erro 4: Inventar Gírias
```
❌ Criar gírias que parecem do nicho mas não existem
✅ Usar apenas gírias encontradas nos swipes
```

---

## Quando Não Há Swipes do Nicho

Se o nicho não tem pasta de swipes:

1. **Buscar nicho similar:**
   - saude-mental → emagrecimento (mesma categoria)
   - pack → renda-extra (mesma categoria)

2. **Usar tom neutro:**
   - Confessional + conversacional
   - Sem gírias específicas
   - Emoção genérica (problema → solução)

3. **Documentar o gap:**
   - Criar swipes após campanha rodar
   - Adicionar à pasta quando validados

---

*Criado: 2026-01-27 | Versão: 1.0*
*Estilo é contextual - sempre descobrir via swipes*
