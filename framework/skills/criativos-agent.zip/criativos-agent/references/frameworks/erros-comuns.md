# Erros Técnicos Recorrentes

> **Os 10 erros mais comuns em criativos de Direct Response e como evitá-los.**

---

## Erro 1: Desorganização do Documento

### O problema
O copywriter imagina o anúncio na cabeça, mas o documento que vai para o editor não contém todas as informações necessárias.

### Informações frequentemente omitidas
- Link do avatar/ator a ser usado
- Referência de edição (link de anúncio similar)
- Música desejada
- Comentários explicativos sobre intenção
- Referência visual para cenas específicas
- Tom de voz desejado

### Consequência
O editor interpreta à sua maneira. O resultado final é completamente diferente do imaginado pelo copy. O anúncio não performa e ninguém entende por quê.

### Solução
Usar template padronizado com campos obrigatórios. O documento deve permitir que qualquer editor recrie exatamente a visão do copywriter.

---

## Erro 2: Prolixidade

### O problema
Explicar em 3 parágrafos o que caberia em 2 frases. Assumir que mais informação = mais persuasão.

### Como identificar
Releia seu anúncio e pergunte: "Eu bocejaria lendo isso?" Se sim, está prolixo.

### Teste prático
Para cada parágrafo, pergunte: "Posso falar isso de forma mais curta?" Se sim, reescreva.

### Exemplo

❌ **Prolixo:**
> "A Maria sempre foi uma pessoa que se preocupou muito com a sua saúde e bem-estar. Desde pequena, ela aprendeu com a sua mãe a importância de cuidar do corpo. Por isso, quando ela percebeu que estava ganhando peso, ficou muito preocupada e decidiu que precisava fazer algo a respeito."

✅ **Conciso:**
> "Maria sempre cuidou da saúde. Quando viu que estava engordando, decidiu agir."

---

## Erro 3: Seguir Estrutura Cegamente

### O problema
O copywriter aprende uma estrutura (hook → história → mecanismo → prova → CTA) e aplica roboticamente, sem avaliar se o resultado está interessante ou entediante.

### Sintoma
O anúncio "está certo" tecnicamente, mas é chato. Tem todos os elementos, mas não prende.

### Solução
A estrutura é um guia, não uma prisão. Depois de escrever, releia como CONSUMIDOR, não como copywriter. Pergunte: "Eu pararia para ver isso no meu feed?"

Se a resposta for não, reescreva — mesmo que signifique "quebrar" a estrutura.

---

## Erro 4: Trocar Elementos Essenciais

### Conceito de Cícero
Todo anúncio tem elementos **ESSENCIAIS** e elementos **ACIDENTAIS**.

### Elementos Essenciais (NÃO MEXER)
- Benefício principal
- Future pacing (projeção de resultado)
- Pontos de dor
- Mecanismo diferenciado
- Prova

Estes estão validados pelo mercado. Funcionam.

### Elementos Acidentais (PODE TESTAR)
- Ordem específica das informações
- Palavras exatas usadas
- Detalhes da história
- Elementos visuais secundários

Se você tirar ou mudar, o anúncio continua funcionando.

### O erro do júnior
Quer "ser criativo" e troca elementos ESSENCIAIS por ideias aleatórias da própria cabeça. Remove o future pacing porque "achou desnecessário". Tira a dor porque "ficou negativo demais". Muda o benefício porque "quis inovar".

**Resultado:** O anúncio para de funcionar e o copywriter não entende por quê.

---

## Erro 5: Falta de Senso Crítico na Revisão

### O problema
O copywriter não relê o próprio anúncio com olhar crítico. Não se coloca no lugar do lead.

### Perguntas que deveriam ser feitas (e não são)
- Eu pararia para ver isso no feed?
- Isso está chato?
- Essa frase é necessária?
- Estou sendo prolixo aqui?
- O hook está forte o suficiente?
- Existe alguma parte que eu pularia se estivesse assistindo?

### Solução
Após escrever, espere pelo menos 30 minutos. Volte e leia como se fosse um lead cético, apressado, desconfiado. Critique impiedosamente.

---

## Erro 6: Hook Sem os 3 Elementos

### O problema
Hook que não qualifica, não emociona ou não gera curiosidade.

### Erro mais comum
"Vocês não vão acreditar no que aconteceu!"
- Não qualifica (quem é o público?)
- Não gera emoção específica
- Curiosidade genérica

### Solução
Todo hook deve ter: QUALIFICAÇÃO + EMOÇÃO + CURIOSIDADE

---

## Erro 7: Usar "Isso Aqui" no Lugar de Nome Chiclete

### O problema
```
"Eu usei ISSO AQUI para emagrecer."
"Faça ISSO todo dia."
"Descobri ISSO e mudou minha vida."
```

### Por que não funciona
- Não qualifica (isso o quê?)
- Não gera curiosidade específica
- Parece clickbait genérico

### Solução
```
"Eu usei o TRUQUE DO GENGIBRE CONGELADO para emagrecer."
"Faça o RITUAL DO VINAGRE todo dia."
"Descobri o MÉTODO JAPONÊS e mudou minha vida."
```

**Regra:** Se existe um nome chiclete para o mecanismo, ele DEVE estar no hook.

---

## Erro 8: Ausência de Voz

### O problema
Copy tecnicamente correta mas sem PERSONALIDADE. Parece documento corporativo, não conversa real.

### Sintomas
- Frases longas e formais
- Linguagem neutra, sem emoção
- Leitura não engaja (correto mas chato)
- Parece "feita por IA"

### Exemplo

❌ **Sem voz:**
> "Este método foi desenvolvido para auxiliar pessoas que desejam melhorar seu desempenho em provas através de técnicas cientificamente comprovadas."

✅ **Com voz:**
> "Você estuda. Estuda. Estuda. E na hora da prova? Erra o que sabia."

### Solução
Ler em voz alta. Se soa como apresentação de PowerPoint, reescrever como desabafo no bar.

---

## Erro 9: Estilo Hardcoded

### O problema
Aplicar o MESMO tom/emoção em TODOS os criativos, independente do nicho.

### Exemplos do erro
- Usar "raiva" em criativo de maternidade (tom inadequado)
- Usar "deboche" em criativo de luto/saúde grave
- Usar gírias de um nicho em outro ("tomando fumo" em diabetes)

### Por que acontece
Copywriter aprende que "raiva vende" em um nicho (ex: concursos) e replica universalmente.

### Solução
1. Identificar o nicho da oferta
2. Ler 2-3 swipes do nicho específico
3. Extrair TOM dominante dos swipes (raiva? vulnerabilidade? esperança?)
4. MODELAR o tom do nicho, não impor tom de outro contexto

**Regra:** Tom é CONTEXTUAL. Descobrir via swipes, não hardcodar.

---

## Erro 10: Ignorar Swipes

### O problema
Inventar estilo do zero ao invés de modelar dos swipes validados.

### Sintomas
- Gírias inventadas que não existem no nicho
- Tom desconectado do que escala no mercado
- Copy "original" que não converte
- Linguagem artificial

### Exemplo

❌ **Ignorou swipes:**
> Criou gíria "Método Explosão Mental" para concursos (não existe no nicho)

✅ **Modelou swipes:**
> Usou "tomando fumo", "famosinhas", "hack" (gírias reais do nicho)

### Solução
ANTES de escrever qualquer palavra:
1. `ls ~/.claude/skills/criativos-agent/references/swipe-files/{nicho}/`
2. Ler 2-3 swipes
3. Documentar tom/gírias/ritmo
4. MODELAR estilo, não inventar

**Regra:** Swipes são OBRIGATÓRIOS. Não existe criativo sem consulta.

---

## Checklist Anti-Erros

```
□ Documento tem todas informações para o editor?
□ Texto é conciso (não prolixo)?
□ Estrutura está a serviço do engajamento (não robótica)?
□ Elementos essenciais estão preservados?
□ Reli como consumidor cético?
□ Hook tem os 3 elementos (Qualificação + Emoção + Curiosidade)?
□ Usei nome chiclete (não "isso aqui")?
□ Copy tem VOZ/PERSONALIDADE (não parece IA)?
□ Tom foi MODELADO dos swipes (não hardcoded)?
□ Li 2-3 swipes ANTES de escrever?
```

---

*Extraído de: Metodologia Vitor Mound (Seção 7) + Upgrade Sistêmico v1.0 | 2026-01-27*
