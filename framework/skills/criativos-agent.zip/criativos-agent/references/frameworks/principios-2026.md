# Princípios de Criativos 2026

## Diagnóstico do Mercado

### O Cenário Atual

1. **Dopamina Baixa**
   - Leads estão saturadas de conteúdo
   - Threshold de atenção cada vez menor
   - Copys longas perdem margem

2. **Migração para DTC**
   - Estilo TikTok Shop ganhando força
   - Copys curtas e diretas
   - Less is more

3. **Ciclo de Mercado**
   - Mercado digital é cíclico
   - Estamos em fase de "simplificação"
   - Volta às origens do direct response

---

## Princípio #1: Benefícios > Dores no Hook

### O Erro Comum
```
❌ "Você está cansado de [dor]?"
❌ "Sofre com [problema]?"
❌ "Frustrado por não conseguir [resultado]?"
```

### A Nova Abordagem
```
✅ "Eu descobri como [benefício] sem [esforço]"
✅ "Consegui [resultado] fazendo [algo inesperado]"
✅ "[Benefício específico] em [timeframe]"
```

### Por que Funciona

- Dores IDENTIFICAM, mas benefícios RETÉM
- Lead já sabe a dor dela - quer saber a SOLUÇÃO
- Benefício gera dopamina imediata (escassa no mercado)

### Regra Prática

```
HOOK = BENEFÍCIO INTRIGANTE + COMO INESPERADO

"Eu descobri como gabaritar lei seca estudando 30min/dia"
         ↑                              ↑
    BENEFÍCIO                    COMO INESPERADO
```

---

## Princípio #2: Formatos Virais como Template

### O Processo

```
1. IDENTIFICAR → Conteúdo orgânico viralizado no nicho
2. ANALISAR → FORMATO (visual) + ÂNGULO (mensagem) separadamente
3. ADAPTAR → Encaixar copy de venda no formato visual
4. MANTER → Estética orgânica (não parecer anúncio)
```

### Por que Funciona

- Formato visual já validado pelo algoritmo
- Linguagem nativa da plataforma
- Não dispara "filtro de anúncio" mental
- Aproveitamento de padrões virais

### Distinção Importante

> **FORMATO** = Embalagem visual (o que a pessoa VÊ)
> **ÂNGULO** = Abordagem da mensagem (COMO a copy é passada)

### Exemplos por Plataforma

| Plataforma | Formato (Visual) | Ângulo (Mensagem) | Exemplo |
|------------|------------------|-------------------|---------|
| TikTok | Andando na Rua | Perigo + Nova Descoberta | "Quase fui preso por..." |
| TikTok | Green Screen | Erro Comum + MUP | "O que ninguém te conta..." |
| Reels | POV Câmera | Identificação + Paradoxo | "POV: você descobriu que..." |
| Reels | Cozinha/Receita | Food Hack + MUS | "Esse chá faz..." |
| YouTube | React/Reação | Prova Social + Antes/Depois | Reagindo a transformação |
| Shorts | Texto Overlay | Alerta + Medo | Texto impactante + reação |
| Facebook | UGC | Nova Descoberta + Conspiração | Pessoa comum revelando segredo |
| Facebook | Tela Dividida | Antes/Depois + Comparação | Resultado visual comparativo |

### Checklist

- [ ] FORMATO existe organicamente na plataforma?
- [ ] FORMATO tem engajamento alto (não pago)?
- [ ] ÂNGULO se encaixa naturalmente no formato?
- [ ] Criativo mantém estética orgânica?
- [ ] Produção visual condiz com o formato escolhido?

---

## Princípio #3: Teses de Marketing Curiosas

### O que é uma Tese Curiosa

Não é só um hook chamativo.
É um **CONCEITO** que sustenta todo o criativo.

### Exemplos

```
TESE FRACA: "Método novo de memorização"
TESE FORTE: "Quase fui preso por usar IA pra passar em concurso"

TESE FRACA: "Emagreça com esse chá"
TESE FORTE: "Meu médico me proibiu de tomar. Funcionou."

TESE FRACA: "Ganhe dinheiro online"
TESE FORTE: "Fui processado por ensinar isso de graça"
```

### Framework de Tese

```
TESE = [ELEMENTO CHOCANTE] + [RESULTADO DESEJADO] + [CONTEXTO ESPECÍFICO]

"Quase fui preso" + "por usar IA pra passar" + "em concurso que reprovei 6x"
```

---

## Princípio #4: Big Ideas com Conceitos Poderosos

### Gimmick Name Vazio vs. Gimmick com Conceito

```
VAZIO (não usar):
- "Método X"
- "Sistema Revolucionário"
- "Técnica Avançada"

COM CONCEITO (usar):
- "Turma do Fundão" (underground, rebeldia)
- "Método Âncora" (fixação, estabilidade)
- "Os 3 Buracos" (problema específico, visual)
```

### Por que Conceitos Funcionam

1. **Memorabilidade** - Fácil de lembrar
2. **Curiosidade** - Quer saber o que é
3. **Diferenciação** - Destaca da concorrência
4. **Storytelling** - Permite narrativa

### Como Criar Conceitos

```
1. Identificar METÁFORA do mecanismo
2. Conectar com EXPERIÊNCIA comum
3. Nomear de forma MEMORÁVEL
4. Validar se gera CURIOSIDADE
```

---

## Princípio #5: CTA Orgânico

### O Erro
```
❌ "CLIQUE AGORA E GARANTA SUA VAGA!"
❌ "COMPRE JÁ COM 50% DE DESCONTO!"
❌ "OFERTA POR TEMPO LIMITADO!"
```

### A Nova Abordagem
```
✅ "Deixei disponível no botão aqui embaixo"
✅ "Acho que ainda tá disponível"
✅ "Se quiser saber mais, o link tá na bio"
```

### Por que Funciona

- Não dispara defesas de "estão me vendendo"
- Mantém tom orgânico do conteúdo
- Urgência implícita ("acho que ainda tá")
- Menos pressão = mais conversão

---

## Checklist 2026

### Antes de Criar

- [ ] Mercado/nicho está em qual ciclo?
- [ ] Qual formato está viralizando organicamente?
- [ ] Qual Big Idea sustenta o criativo?
- [ ] Tese é curiosa ou genérica?

### Durante a Criação

- [ ] Hook abre com BENEFÍCIO?
- [ ] Formato parece ORGÂNICO?
- [ ] Gimmicks têm CONCEITO?
- [ ] CTA é SUAVE?

### Depois de Criar

- [ ] Passaria como conteúdo orgânico?
- [ ] Gera curiosidade imediata?
- [ ] Lead entenderia em 5 segundos?
- [ ] Tem diferencial claro?

---

## Resumo dos Princípios

| # | Princípio | Implementação |
|---|-----------|---------------|
| 1 | Benefícios > Dores | Abrir hook com benefício intrigante |
| 2 | Formatos Virais | Copiar estrutura de conteúdo orgânico |
| 3 | Teses Curiosas | Conceito forte que sustenta o criativo |
| 4 | Big Ideas | Gimmicks com conceito, não vazios |
| 5 | CTA Orgânico | Tom suave, não agressivo |
