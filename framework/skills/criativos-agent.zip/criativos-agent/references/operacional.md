# Operacional: Estrutura + Workflow

> Referência para MODELAR estruturas — não fórmula fixa.
> Copy Chief JULGA e CRIA/MODELA. Todo criativo tem estrutura invisível ÚNICA.

---

## Arquitetura de Referência

> Esta é a anatomia COMUM. Criativos reais variam — extraia padrões dos swipes.

```
┌─────────────────────────────────────────┐
│           FORMATO                       │
│  Embalagem visual que dispara dopamina  │
│  antes de uma palavra ser dita          │
│  (UGC, Tela Dividida, POV, etc.)        │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│           HOOK (0-5s)                   │
│  80/20 do criativo                      │
│  Define QUEM para e QUEM continua       │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│         TRANSIÇÃO                       │
│  Conecta hook ao body                   │
│  Ameniza ou continua a tensão           │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│           BODY                          │
│  - Identifica (avatar se vê)            │
│  - Revela MUP (por que falhou)          │
│  - Apresenta MUS (por que vai funcionar)│
│  - Prova (credibilidade)                │
│  - Future Pacing (visualiza resultado)  │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│           CTA                           │
│  Indireto → Direto                      │
│  Transfere euforia para o link          │
└─────────────────────────────────────────┘
```

---

## Método Twenty Five

> Antes de escolher um hook, gere 25 variações. Não 3. Não 5. VINTE E CINCO.

### Por quê?
- As primeiras ideias são óbvias (todo mundo pensa igual)
- A partir da 15ª você força conexões novas
- Big Ideas aparecem quando o óbvio acaba

### Como fazer:
1. Defina o ÂNGULO principal
2. Gere 25 hooks diferentes para esse ângulo
3. Avalie cada um contra os fundamentos de Psicologia
4. Selecione os 3 melhores
5. Teste no criativo

### Variações possíveis:
- Mudar a emoção (raiva → curiosidade → medo)
- Mudar a especificidade (número diferente, detalhe diferente)
- Mudar o paradoxo (inversão diferente)
- Mudar a persona (eu fiz → ela fez → eles descobriram)
- Mudar o tempo verbal (presente → passado → futuro)

---

## Elementos do Body (Referência)

Não existe ordem fixa. Use conforme o contexto:

| # | Elemento | Função |
|---|----------|--------|
| 1 | **Identificação** | Avatar se vê na copy |
| 2 | **Reason Why** | Explicação lógica pós-hook |
| 3 | **MUP** | Mecanismo do Problema (por que falhou) |
| 4 | **MUS** | Mecanismo da Solução (por que vai funcionar) |
| 5 | **Quebra de Ceticismo** | "Sei que parece bom demais..." |
| 6 | **Reforço de Benefícios** | O que vai acontecer |
| 7 | **Credibilidade** | Prova social, autoridade, estudos |
| 8 | **Comparação** | Diferencia de outras soluções |
| 9 | **Quebra de Objeções** | "Você não precisa..." |
| 10 | **Detalhamento/Prova** | Evidências específicas |
| 11 | **Future Pacing** | Visualizar o resultado |
| 12 | **Escassez/Urgência** | Por que agora |

---

## Workflow Completo

### FASE 0: Contexto
```
□ Ler research da oferta (synthesis.md, summaries)
□ Ler briefings HELIX (MUP, MUS, Avatar)
□ Consultar 3+ swipes do nicho
□ Extrair: TOM, GÍRIAS, RITMO dos swipes
```

### FASE 1: Definição
```
□ Definir FORMATO (UGC, Tela Dividida, POV, etc.)
□ Definir ÂNGULO (Nova Descoberta, Conspiração, Paradoxo, etc.)
□ Definir CLUSTER (segmento específico do avatar)
□ Definir NÍVEL DE CONSCIÊNCIA (Problem/Solution/Product Aware)
```

### FASE 2: Big Idea
```
□ Aplicar os 4 fundamentos de interrupção:
  - Especificidade
  - Inversão
  - Revelação
  - Relevância
□ Gerar 25 variações de hook
□ Selecionar top 3
```

### FASE 3: Construção
```
□ HOOK: Aplicar 3 elementos (Qualificação + Emoção + Curiosidade)
□ HOOK: Verificar NUUPPECC (mínimo 4-5 atributos)
□ TRANSIÇÃO: Conectar hook ao body
□ BODY: Combinar elementos conforme contexto (ver tabela acima)
□ BODY: Inserir disparos de dopamina após partes técnicas
□ CTA: Indireto → Direto
```

### FASE 4: Refinamento
```
□ Aplicar sinestesia (mínimo 3 sentidos)
□ Variar ritmo (curto + médio + longo)
□ Verificar transições invisíveis
□ Teste da Mão (curiosity gap)
□ Ler em voz alta (sem engasgar)
```

### FASE 5: Validação
```
□ Checklist de Psicologia
□ Checklist de Escrita
□ Gate de Saída (8 blocos metodológicos)
```

---

## Formatos Principais

| Formato | Quando usar | Características |
|---------|-------------|-----------------|
| **UGC Talking Head** | Depoimento, confessional | Câmera frontal, tom pessoal |
| **Tela Dividida** | Comparação, antes/depois | Duas cenas simultâneas |
| **POV** | Imersão, experiência | Câmera em primeira pessoa |
| **React** | Comentar conteúdo viral | Reação + análise |
| **Green Screen** | Notícia, autoridade | Cenário virtual |
| **Podcast Style** | Conversa, credibilidade | Duas pessoas dialogando |

---

## Ângulos Validados

| Ângulo | Big Idea típica | Emoção dominante |
|--------|-----------------|------------------|
| **Nova Descoberta** | "Acabaram de descobrir..." | Curiosidade |
| **Conspiração** | "O que X esconde de você..." | Indignação |
| **Paradoxo** | "Fazer menos para ter mais..." | Surpresa |
| **Erro Comum** | "O que todo mundo faz errado..." | Reconhecimento |
| **Confessional** | "Eu não queria contar isso, mas..." | Vulnerabilidade |
| **Evento Recente** | "Ontem aconteceu algo..." | Urgência |
| **Comparação** | "X vs Y - a verdade..." | Clareza |

---

## Distinção Crítica: Formato vs Ângulo

| Conceito | Definição | Exemplos |
|----------|-----------|----------|
| **FORMATO** | Embalagem visual (o que VÊ) | UGC, Podcast, Tela Dividida |
| **ÂNGULO** | Abordagem da mensagem (COMO diz) | Nova Descoberta, Paradoxo, Conspiração |

**Importante:** Um MESMO ângulo pode ser executado em VÁRIOS formatos.
- "Nova Descoberta" em UGC
- "Nova Descoberta" em Tela Dividida
- "Nova Descoberta" em Podcast Style

---

## Consulta a Swipes (Obrigatório)

### Antes de escrever qualquer palavra:
1. Identificar nicho da oferta
2. Consultar `references/swipe-files/{nicho}/`
3. Selecionar mínimo 3 referências coerentes
4. Extrair de cada:
   - Hook/Ângulo usado
   - Gimmick Name
   - Estrutura de blocos
   - Elemento a modelar

### Busca em nichos similares:
Se o nicho exato tem poucos swipes, buscar nichos adjacentes com:
- Mesmo PÚBLICO (idade, gênero, situação)
- Mesmo TIPO DE DOR (física, emocional, financeira)
- Mesmo MECANISMO (causa oculta, método rápido, etc.)

---

## Output do Criativo

### Estrutura do arquivo de entrega:

```markdown
# [NOME DO CRIATIVO]

## Metadata
- **Formato:** [tipo]
- **Duração:** [Xs]
- **Plataforma:** [Meta/YouTube/TikTok]
- **Nível de Consciência:** [qual]
- **Big Idea:** [resumo em 1 frase]
- **Ângulo:** [qual]

## GATE: Arquivos Lidos
[Evidência de leitura dos arquivos obrigatórios]

---

## HOOK - 3 Variações

### H1 (PRINCIPAL)
[hook]

### H2
[variação]

### H3
[variação]

---

## COPY PRINCIPAL

### [BLOCO - Xs]
[copy]

### [BLOCO - Xs]
[copy]

---

## ANÁLISE TÉCNICA

| Elemento | Aplicação |
|----------|-----------|
| Big Idea | ... |
| Swipes usados | ... |
| NUUPPECC | X/8 |
| Sinestesia | X/6 sentidos |
| MUP | ... |
| MUS | ... |

---

## GATE DE SAÍDA: Validação Metodológica
[8 blocos de validação]
```

---

*Consolidado de: estrutura-criativos.md, SKILL.md, workflow interno*
*v1.0 | 2026-01-28*
