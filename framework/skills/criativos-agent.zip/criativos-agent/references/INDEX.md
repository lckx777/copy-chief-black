# Índice de Swipe Files

> **147 swipes** organizados em **24 nichos**.
> Atualizado: 2026-01-30

---

## Nichos por Categoria

### Saúde (67 swipes)
| Nicho | Qtd | Path |
|-------|-----|------|
| diabetes | 12 | `swipe-files/diabetes/` |
| emagrecimento | 12 | `swipe-files/emagrecimento/` |
| ed | 12 | `swipe-files/ed/` |
| rejuvenescimento | 6 | `swipe-files/rejuvenescimento/` |
| exercicios | 6 | `swipe-files/exercicios/` |
| sexualidade | 6 | `swipe-files/sexualidade/` |
| prostata | 5 | `swipe-files/prostata/` |
| menopausa | 4 | `swipe-files/menopausa/` |
| aumento-peniano | 4 | `swipe-files/aumento-peniano/` |
| saude-mental | 4 | `swipe-files/saude-mental/` |
| prisao-de-ventre | 4 | `swipe-files/prisao-de-ventre/` |
| visao | 4 | `swipe-files/visao/` |
| pressao-alta | 3 | `swipe-files/pressao-alta/` |
| alzheimer | 3 | `swipe-files/alzheimer/` |
| varizes | 2 | `swipe-files/varizes/` |

### Relacionamento (10 swipes)
| Nicho | Qtd | Path |
|-------|-----|------|
| relacionamento | 10 | `swipe-files/relacionamento/` |

### Riqueza (18 swipes)
| Nicho | Qtd | Path |
|-------|-----|------|
| lei-da-atracao | 10 | `swipe-files/lei-da-atracao/` |
| renda-extra | 10 | `swipe-files/renda-extra/` |

### Concursos (4 swipes)
| Nicho | Qtd | Path |
|-------|-----|------|
| concursos | 4 | `swipe-files/concursos/` |

### Outros (26 swipes)
| Nicho | Qtd | Path |
|-------|-----|------|
| escrita | 8 | `swipe-files/escrita/` |
| infantil-maternidade | 5 | `swipe-files/infantil-maternidade/` |
| pack | 5 | `swipe-files/pack/` |
| moda | 4 | `swipe-files/moda/` |
| pet | 3 | `swipe-files/pet/` |

---

## Como Usar

### Para Criativos de Nicho Específico
```
Carregar: references/swipe-files/{nicho}/
Exemplo: references/swipe-files/diabetes/
```

### Para Análise de Padrões Cross-Nicho
```
1. Identificar nichos similares (ex: saúde → diabetes, emagrecimento)
2. Carregar 2-3 swipes de cada
3. Extrair padrões comuns
```

### Qual Swipe Usar?
| Situação | Nichos Recomendados |
|----------|---------------------|
| Oferta de saúde | diabetes, emagrecimento, ed |
| Oferta de relacionamento | relacionamento |
| Oferta de concursos | concursos |
| Oferta de renda | renda-extra, lei-da-atracao |

---

## Swipes por Nicho (Detalhado)

### concursos/ (4 swipes)
- ADS 79 GPT LANE.md
- ADS HACKER 37.md
- ADS 77 GPT LANE 01.md
- AD 91 - GPT DOS APROVADOS.md

### diabetes/ (12 swipes)
[Listar ao carregar]

### emagrecimento/ (12 swipes)
[Listar ao carregar]

### ed/ (12 swipes)
- blue-salt-trick---nordic-power-01.md
- truque-do-cavalo.md
- trick-blue-01.md
- truque-da-agua.md
- truque-do-pepino-esp.md
- bacteria-inflamatoria-06.md
- [+ 6 mais]

### relacionamento/ (10 swipes)
- efeito-nostalgia-02.md
- 3-gatilhos-biologicos-da-atracao.md
- formula-do-amor-verdadeiro.md
- desenrolado.md
- manipulacao-silenciosa-01.md
- guia-da-obsessao-inabalavel-01.md
- hormonios-do-amor-02.md
- guia-da-obsessao-inabalavel-02.md
- perfume-de-eros.md
- hormonios-do-amor-04.md

---

## Estrutura de Cada Swipe

Cada arquivo contém:
- **Metadata**: formato, ângulo, performance
- **Hook**: primeiros 3 segundos transcritos
- **Body**: estrutura do anúncio
- **Técnicas**: gatilhos identificados
- **Análise**: por que funciona

---

## Core References (Não-Swipes)

| Arquivo | Propósito |
|---------|-----------|
| `core/estrutura-body.md` | Estrutura de body copy |
| `core/metodologia-hooks.md` | Metodologia de hooks |
| `core/big-ideas.md` | Big ideas e ângulos |
| `core/psicologia-humana.md` | Psicologia aplicada |
| `angulos/angulos-validados.md` | Ângulos testados |
| `glossario.md` | Termos e definições |
| `psicologia.md` | Framework psicológico |

---

*Atualizado automaticamente - v6.0*
