# Metodologia de Breakdown de Criativos

## Sumário
1. [O Que É o Breakdown](#o-que-é-o-breakdown)
2. [Cabeçalho Estratégico](#cabeçalho-estratégico)
3. [Estrutura da TAG Completa](#estrutura-da-tag-completa)
4. [Elementos da Oferta](#elementos-da-oferta)
5. [Formato Final](#formato-final)
6. [Exemplo Prático Completo](#exemplo-prático-completo)

---

## O Que É o Breakdown

Processo para:
- Entender a **intenção psicológica** de cada trecho
- Identificar **mecanismos mentais** acionados
- Mapear **funções estratégicas ocultas**
- Decompor texto para revelar a "engenharia da persuasão"
- **Reconstruir** criativos mantendo performance

> Você decodifica o criativo como um engenheiro de copy.

### Princípio Fundamental

O breakdown **NÃO segue fórmulas rígidas**. Segue a **psicologia real presente no texto**.

---

## Cabeçalho Estratégico

Antes de analisar, identificar 5 elementos:

### 1. FORMATO
Embalagem do criativo:
- UGC, Cinematográfico, Depoimento, POV
- Notícias simuladas, Conversa, Podcast, Expert

### 2. ÂNGULO PRINCIPAL
Abordagem que governa a atenção:
- Quick & Fast, Nova Descoberta, Mecanismo da Solução
- Mecanismo do Problema, Conspiração, Prova Social
- Erro Comum, Pergunta Paradoxal

### 3. CLUSTER MAIS PROVÁVEL
Combinar tom + linguagem + dores implícitas para inferir público.

### 4. PROMESSA PRINCIPAL
Transformação ou resultado dominante (explícito ou implícito).

### 5. ELEMENTOS DE CURIOSIDADE
Métodos, rituais, nomes proprietários. Formato: `(curiosidade: nome)`

---

## Estrutura da TAG Completa

Cada bloco deve ter uma TAG que contenha **TODOS os elementos identificáveis**:

### Anatomia da TAG

```
[Tipo de Elemento + Dor/Emoção (se houver) + Gatilho (se houver) + MUP/MUS/MU (se houver) + Intenção estratégica]
```

### Componentes da TAG

| Componente | Descrição | Exemplos |
|------------|-----------|----------|
| **Tipo de Elemento** | Função estrutural do bloco | Gancho, Apresentação de solução, Quebra de objeção, CTA, Transição |
| **Dor/Emoção** | Dor específica ou emoção ativada | frustração por não ter terminado estudos, medo de ficar para trás, culpa |
| **Gatilho** | Gatilho mental/reptiliano acionado | identificação, escassez temporal, urgência, exclusividade, pertencimento |
| **MUP** | Mecanismo do Problema presente | abandono educacional por falta de tempo, sistema limitado |
| **MUS** | Mecanismo da Solução presente | programa anual oficial, prova única, diploma rápido |
| **MU** | Mecanismo Único presente | método 1-dia, recuperar todos os anos com uma única prova |
| **Intenção** | Objetivo estratégico do bloco | capturar atenção, gerar surpresa, eliminar resistência, forçar ação |

### Regras da TAG

1. **Inclua TUDO que estiver presente** - não omita elementos identificáveis
2. **Use linguagem específica** - "frustração por não ter terminado os estudos" > "frustração"
3. **Sempre inclua a Intenção** - revela o propósito estratégico do bloco
4. **MUP/MUS/MU são obrigatórios** quando identificáveis no trecho
5. **A TAG fica ACIMA do trecho** entre colchetes [ ]

### Formato da TAG

```
[Tipo + Dor (especificada) + Gatilho + Mecanismo + Intenção: objetivo]
 Trecho original sem alterações...
```

---

## Elementos da Oferta

### DORES (explícitas ou ocultas)
- Frustração crônica
- Culpa leve
- Sensação de estar ficando para trás
- Cansaço, insegurança
- Vergonha silenciosa

### MUP (Mecanismo do Problema)
Verdadeiro motivo que **impede** o prospect de resolver:
- Falta de tempo
- Abandono estrutural
- Sistema que só dá uma chance por ano
- Desinformação
- Crença limitante de que é tarde demais
- Rotina caótica

### MUS (Mecanismo da Solução)
O que **resolve** a dor com lógica, clareza ou facilidade:
- Exame gratuito
- Prova única
- Diploma válido ainda este ano
- Programa oficial anual

### MU (Mecanismo Único)
Diferencial **proprietário, simbólico ou estratégico**:
- Método 1-dia
- Ritual do recomeço
- Certificação invisível
- Diploma sem precisar voltar pra escola
- Recuperar todos os anos com uma única prova

### ELEMENTOS DE CURIOSIDADE

**Diferente de ganchos genéricos.** São termos, rituais, símbolos ou mecanismos **próprios da oferta**.

✅ Bom: `(curiosidade: método 1-dia)`, `(curiosidade: ritual do recomeço)`
❌ Ruim: "fórmula mágica", "truque oculto"

---

## Formato Final

### Cabeçalho Estratégico
```
FORMATO:
ÂNGULO:
CLUSTER:
PROMESSA:
ELEMENTOS DE CURIOSIDADE:
```

### Breakdown por Blocos
```
[TAG completa com todos os elementos]
 Trecho original...

[TAG completa com todos os elementos]
 Trecho original...
```

---

## Exemplo Prático Completo

### Criativo Analisado: Encceja

**CABEÇALHO ESTRATÉGICO**
```
FORMATO: UGC / Talking Head
ÂNGULO: Mecanismo da Solução + Nova Oportunidade
CLUSTER: Adultos 25-50 que não concluíram estudos, classe C/D, trabalhadores
PROMESSA: Concluir todos os anos perdidos com apenas 1 prova em 1 dia
ELEMENTOS DE CURIOSIDADE: (curiosidade: método 1-dia), (curiosidade: prova única anual)
```

**BREAKDOWN POR BLOCOS**

```
[Gancho emocional + Dor (frustração por não ter terminado os estudos) + Gatilho de identificação + MUP (abandono educacional por falta de tempo) + Intenção: capturar atenção de quem carrega essa dor silenciosa]
 Eu quero falar com vocês nesse vídeo sobre o Encceja… você que não teve tempo de concluir seus estudos por algum motivo lá no passado…

[Apresentação de solução + Exclusividade + Gatilho de escassez temporal + MUS (programa anual oficial) + Intenção: mostrar que existe uma chance rara e legítima]
 …só que hoje você pode participar desse programa que acontece 1 vez por ano aqui no Brasil.

[Apresentação de benefício principal + Curiosidade (método 1-dia) + MU (recuperar todos os anos com uma única prova) + Intenção: gerar surpresa e desejo por algo simples e eficaz]
 Você consegue concluir todos os anos que você perdeu na escola, realizando apenas 1 prova em único dia.

[Quebra de objeção + Facilidade + Promessa clara + MUS (prova fácil + diploma rápido) + Intenção: eliminar resistência com incentivo positivo]
 A prova é muito fácil e você recebe o diploma ainda esse ano.

[CTA direto + Urgência real + Gatilho de escassez + MUP (prazo curto e definitivo) + Intenção: forçar ação imediata antes da oportunidade desaparecer]
 Clica aqui no botão saiba mais e faça a sua inscrição que o prazo já está acabando.
```

---

## Checklist de Validação

- [ ] Cabeçalho estratégico completo (5 elementos)
- [ ] Cada bloco tem TAG completa entre colchetes [ ]
- [ ] TAGs incluem: Tipo + Dor/Emoção + Gatilho + Mecanismos + Intenção
- [ ] MUP/MUS/MU identificados quando presentes
- [ ] Intenção estratégica presente em TODAS as TAGs
- [ ] Dores e gatilhos são específicos (não genéricos)
- [ ] Curiosidades usam nomenclatura da oferta
- [ ] Trechos originais não foram editados
