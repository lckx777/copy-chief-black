# Checklist de Entrega

> Validação unificada antes de entregar qualquer criativo.
> Máximo 10 itens essenciais.

---

## Gate de Entrada (ANTES de escrever)

| # | Verificação | Status |
|---|-------------|--------|
| 1 | **Li research da oferta?** (synthesis.md, summaries, briefings) | □ |
| 2 | **Consultei 3+ swipes do nicho?** (extraí tom, gírias, ritmo) | □ |
| 3 | **Big Idea tem os 3 elementos Khayat?** (PERSONAGEM + CENA + TENSÃO) | □ |
| 3b | **Contability Test passou?** ("Nossa, vi um anúncio que [___]" é interessante?) | □ |

---

## Gate de Saída (DEPOIS de escrever)

### Psicologia

| # | Verificação | Status |
|---|-------------|--------|
| 4 | **Hook tem os 3 elementos?** (Qualificação + Emoção + Curiosidade) | □ |
| 5 | **NUUPPECC ≥ 5/8?** (Novo, Urgente, Único, Paradoxal, Pessoal, Específico, Concreto, Controverso) | □ |
| 6 | **MUP/MUS são claros e específicos?** (não genéricos) | □ |

### Escrita

| # | Verificação | Status |
|---|-------------|--------|
| 7 | **Sinestesia ≥ 3 sentidos?** (visual, auditivo, tátil, temporal, proprioceptivo, social) | □ |
| 8 | **Tom de WhatsApp?** (não PowerPoint) — Lido em voz alta sem engasgar? | □ |

### Humanidade

| # | Verificação | Status |
|---|-------------|--------|
| 9 | **Pararia de rolar o feed?** (Se não → reescrever hook) | □ |
| 10 | **Se soubesse que foi IA, ainda confiaria?** (Se não → humanizar) | □ |

---

## Critérios de Aprovação

| Resultado | Ação |
|-----------|------|
| **10/10** | Aprovado para entrega |
| **8-9/10** | Revisar itens faltantes |
| **< 8/10** | Reescrever |

---

## Validação Rápida (3 Perguntas)

Se não tiver tempo para o checklist completo:

1. **A lead pularia da cama?** (Big Idea tem interrupção de padrão?)
2. **A lead se vê na copy?** (Sinestesia da rotina real?)
3. **Soa como pessoa, não como IA?** (Tom de WhatsApp?)

---

## Red Flags (Rejeição Automática)

- [ ] Hook usa "isso aqui" em vez de Gimmick Name
- [ ] MUP/MUS genéricos (não específicos da oferta)
- [ ] Sem evidência de leitura dos arquivos (seção GATE vazia)
- [ ] Frases longas demais (> 12 palavras como padrão)
- [ ] Future Pacing abstrato ("você vai se sentir melhor")
- [ ] Transições anunciadas ("Mas voltando ao assunto...")
- [ ] **Big Idea é só promessa crua** ("Perca X kg" sem PERSONAGEM+CENA+TENSÃO)
- [ ] **Contability Test falhou** (não consegue completar "vi um anúncio que...")

---

*Consolidado de: checklist-humanidade.md, erros-comuns.md, revisao-universal.md*
*v1.0 | 2026-01-28*
